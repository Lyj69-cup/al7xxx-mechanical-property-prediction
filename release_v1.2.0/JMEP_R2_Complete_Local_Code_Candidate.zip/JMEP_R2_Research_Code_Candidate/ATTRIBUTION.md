# Attribution and redistribution scope

Code is distributed under the accompanying MIT License. Third-party numeric
observations retain their original source licenses and attribution requirements;
the MIT license does not transfer to third-party papers or experimental data.
The condition ledgers identify each original DOI, target locator and aggregation
qualification. No publisher PDF, HTML/XML full text, page image, manuscript,
private account material, token, model pickle or machine environment is included.

Primary training sources and source-specific definitions are retained in
input_base/data/primary_traceable.csv. Added external/follow-up DOIs are:
- He2025: 10.1016/j.jallcom.2025.182093
- Zhang2026: 10.3390/ma19030479
- Jiang2026: 10.11900/0412.1961.2025.00184
- P15-02: 10.3390/met13101638
- Sajadifar2021: 10.3390/met11071142
- Zhao2020: 10.3390/ma13184022

Original archived plans retain relative paths and hashes of privately inspected
source files, including full texts. These hashes document the audit history;
the full texts themselves are not distributed and are not needed for numerical
reproduction from the curated inputs. Obtain originals lawfully via their DOIs
to audit transcription. Graph-read UTS entries are explicitly distinguished from
table/text values. No new physical experiments or specimen identities are claimed.
