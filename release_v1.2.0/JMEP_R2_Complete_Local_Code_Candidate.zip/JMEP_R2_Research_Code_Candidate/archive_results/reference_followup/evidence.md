# Complete bounded UTS reference follow-up

Completed locally on5November2026. No model, grid or externally published file was modified. All three specified papers and all four eligible fixed-temperature, positive-time aging series were included. Tai was excluded because it is already in the98-row training cohort.

## Chronology and information budget

This follow-up was planned after the favorable He2025 UTS one-anchor result and the unfavorable AMS comparison were known. All three follow-up publications and target values had previously been inspected in a related hardness project. The current method list, eligible row IDs, earliest-time anchors and readout sensitivity rules were frozen before any current follow-up model prediction. This is a retrospective, posthoc-origin development follow-up, not a blinded or untouched external confirmation.

There are16source conditions, four consumedUTSreference values and12queryconditions from three papers. The Sajadifar paper supplies two temperature series; these are not two independent publications. One earliest eligible aging-timeUTS is consumed for each series. The same12queries are used for all12methods, including every frozen control. Zero-shot comparisons use no reference target; anchored methods use extra information, so improvement versus zero-shot cannot be attributed purely to algorithm choice.

## Source and feature qualification

- P15-02, DOI10.3390/met13101638, uses120°C aging for18/21/24/27/30h. OriginalPDFp2 reports2.0mmsheet,6.21Zn/2.16Mg/1.82Cu/0.39Mn/0.11Fe/0.08Si,470°C38min solution andwaterquench; p3 reports three tensile tests averaged andRDorientation. Fig7a,p6 supplies graph-readUTS553/554/556/555/555MPa. PriorNA and tensile test temperature remain unreported. No registered AA grade is invented.

- Sajadifar2021, DOI10.3390/met11071142, uses105°C and120°C, each at2/15/24h with0MPa applied stress. Methodspp3–4/Table1 report ENAW7075 extrudedbar,15mmdiameter, measuredchemistry,480°C30min solution and20°Cwaterquench. Prompt mounting toavoidNA doesnot establish exact0days; bar diameter isnot sheet gauge;0MPa isnot0%prestrain. Figs4b/5b,pp6–7 give graph-readUTS560/557/587 and541/573/555MPa. Three tensile tests and average/scatter are reported; the bars are not assigned an unreportedSDdefinition. Roomtemperature is explicitly reported for tensile testing.

- Zhao2020, DOI10.3390/ma13184022, uses140°C at8/10/12/14/16h. Methodspp2–3/Table1 report7075, extrusion450°Cratio8 followed byrolling to2mmsheet,468°C20min solution inmoltennitrates andimmediatewaterquench. Table2,p5 suppliesUTS503.2/515.3/509.5/508.8/511.6MPa. Five hardness indents are not five tensile repeats; tensile aggregation/count and test temperature remain unknown. The0h solution state andDA treatment are not part of the previously defined fixed140°Cpositive-time series, rather than being removed based on prediction error.

Unreported minor elements, pre-aging strain and prior natural-aging duration remain missing. No assumedRT values or hardness variables enter the predictors. P15/Zhao sheet gauges are genuine source-reported gauges; Sajadifar coupon/bar geometry is not substituted for a missing sheet gauge. The copied frozen feature transform reproduces all98training45-column vectors exactly before producing the16external45/53vectors.

## Complete method summaries

All entries are queryUTSMAE inMPa. Source-macro and pooledMAE happen to coincide here because each of the three papers contributes fourqueries; series-macro weights the two Sajadifar series separately. This numerical coincidence is not evidence of source independence.

| Method | Pooled MAE | Source-macro MAE | Conditional readout best–worst MAE |
|---|---|---|---|
| anchor_constant | 9.7000 | 9.7000 | 7.5000–13.2333 |
| anchor_offset__chem18_ridge10 | 9.7000 | 9.7000 | 7.5000–13.2333 |
| anchor_offset__fixed_ET45 | 6.2812 | 6.2812 | 4.4330–9.5842 |
| anchor_offset__nested_joint | 7.6518 | 7.6518 | 5.8217–10.9719 |
| anchor_offset__ridge100_raw32 | 6.7364 | 6.7364 | 4.4375–9.7697 |
| anchor_offset__training_mean | 9.7000 | 9.7000 | 7.5000–13.2333 |
| anchor_plus_fixed_source_logtime_slope | 10.9657 | 10.9657 | 7.7133–14.9907 |
| zero_shot__chem18_ridge10 | 72.5188 | 72.5188 | 70.5021–74.5354 |
| zero_shot__fixed_ET45 | 41.4586 | 41.4586 | 39.4419–43.4752 |
| zero_shot__nested_joint | 23.8708 | 23.8708 | 21.8542–25.8875 |
| zero_shot__ridge100_raw32 | 35.8744 | 35.8744 | 33.8577–37.8910 |
| zero_shot__training_mean | 24.4220 | 24.4220 | 22.4054–26.4387 |

## All declared series

| Series | Method | Nominal MAE | Conditional readout best–worst MAE |
|---|---|---|---|
| HV32-S05 | zero_shot__nested_joint | 7.6200 | 4.6200–10.6200 |
| HV32-S05 | anchor_constant | 2.0000 | 0.0000–8.0000 |
| HV32-S05 | anchor_offset__nested_joint | 0.8902 | 0.0000–6.2507 |
| HV32-S05 | anchor_plus_fixed_source_logtime_slope | 4.9301 | 0.6827–10.9301 |
| HV32-S05 | anchor_offset__fixed_ET45 | 0.9695 | 0.0000–6.3036 |
| HV32-S05 | anchor_offset__ridge100_raw32 | 4.3277 | 0.5311–10.3277 |
| HV32-S08 | zero_shot__nested_joint | 34.8582 | 31.8582–37.8582 |
| HV32-S08 | anchor_constant | 15.0000 | 12.0000–18.0000 |
| HV32-S08 | anchor_offset__nested_joint | 13.6321 | 10.6321–16.6321 |
| HV32-S08 | anchor_plus_fixed_source_logtime_slope | 28.5042 | 22.5042–34.5042 |
| HV32-S08 | anchor_offset__fixed_ET45 | 14.6548 | 11.6548–17.6548 |
| HV32-S08 | anchor_offset__ridge100_raw32 | 11.2034 | 8.2034–14.2034 |
| HV32-S09 | zero_shot__nested_joint | 31.4206 | 28.4206–34.4206 |
| HV32-S09 | anchor_constant | 23.0000 | 17.0000–29.0000 |
| HV32-S09 | anchor_offset__nested_joint | 17.5143 | 11.5143–23.5143 |
| HV32-S09 | anchor_plus_fixed_source_logtime_slope | 17.5042 | 12.6342–23.5042 |
| HV32-S09 | anchor_offset__fixed_ET45 | 16.2266 | 10.2266–22.2266 |
| HV32-S09 | anchor_offset__ridge100_raw32 | 12.7966 | 9.7966–15.7966 |
| HV32-S12 | zero_shot__nested_joint | 30.8531 | 30.8031–30.9031 |
| HV32-S12 | anchor_constant | 8.1000 | 8.0000–8.2000 |
| HV32-S12 | anchor_offset__nested_joint | 6.4919 | 6.3919–6.5919 |
| HV32-S12 | anchor_plus_fixed_source_logtime_slope | 4.9629 | 4.8879–5.0379 |
| HV32-S12 | anchor_offset__fixed_ET45 | 2.4334 | 2.3584–2.5084 |
| HV32-S12 | anchor_offset__ridge100_raw32 | 3.8816 | 3.7816–3.9816 |

The primary frozen-model offset has nominalMAE7.6518MPa versus9.7000MPa for carrying the reference constant and23.8708MPa for the frozen-model zero-shot prediction. The nominal constant-to-offset changes are2.0000→0.8902(P15),15.0000→13.6321(Sajadifar105°C),23.0000→17.5143(Sajadifar120°C), and8.1000→6.4919(Zhao). All four nominal comparisons improve, but that is insufficient to claim a robust general gain.

## Readout sensitivity

P15/Sajadifar±3MPa is a previously chosen project conservative graph-reading allowance. It isnot an experimentalSD, confidence interval or guaranteed bound on the true measurement. Zhao±0.05MPa is half of the printed0.1MPa precision,not experimental uncertainty. All sensitivities are conditional on frozen inputs/models and these allowances; they do not account for unreported specimen variation,chemistry error or full model uncertainty.

For a series with nominal errors e_i, sharedanchor perturbation δ in[−a,a] and individual query allowances b_i, worstMAE=max(mean|e_i−a|,mean|e_i+a|)+mean(b_i). BestMAE minimizes mean max(|e_i+δ|−b_i,0) over interval endpoints and knots−e_i±b_i. Sharedanchor perturbation affects all queries together. An independent convex-optimization implementation reproduces all48series/method bounds. No interval is labeled a statisticalCI.

P15/Sajadifar nominal gains versus reference-constant are below6MPa and do not establish robust improvements under the stipulated graph-reading allowances. Zhao has reference-constantMAE[8.0000,8.2000] versus frozen-joint-offset[6.3919,6.5919], giving a conservative positive gain lower bound1.4081MPa within the rounding-only allowance. This supports only a limited case-specific arithmetic improvement; unreported experimental variability prevents a statistical significance claim.

## What the study does and does not support

The one-reference strategy supplies a small practical feasibility signal: known local reference strength can correct cross-study level mismatch and allow limited relative-change prediction. It is not a new learning algorithm or universal engineering qualification. On this complete follow-up, fixedET45offset has lower pooledMAE6.2812 than primary nestedjointoffset7.6518. OnZhao, the original-source simplelogtime slope givesMAE4.9629, lower than the nestedoffset6.4919. Consequently the follow-up doesnot establish unique ML superiority, nor may we silently select a different winner per target or source. The primary frozen nested predictor and all controls remain fixed and fully reported.

## Verification and files

`audit_results.json` isPASS. It independently reconstructs all144forecasts, checks all16sourceconditions/4anchors/12queries, confirms all48seriesmetric/readout-band rows, reproduces interval bounds through independent scalar optimization, verifies immutable source/model hashes and confirms no query targets in feature or predictivefunction inputs. No model was fitted or clipped. The80zero-shot predictions include all16conditions for five frozenUTSpredictors; the144scored predictions cover only12queries for12methods.

Primaryoutputs are frozenplan/lock, conditionledger, targetledger,4consumedanchors,45/53matrices, zero-shotallconditions, predictionsbefore-scoring/lock, scoredpredictions, series/source/pooledmetrics, pairedgainreadoutbounds, curationchecks and auditchecks. Sourcepage text/PNGs are private QA intermediates and must not be redistributed as full-text components of a public data/code release.

Reproduce sequentially with the bundled study environment: curate_and_freeze.py, forecast_followup.py, score_followup.py, audit_followup.py. The first script refuses to overwrite a differing frozenplan. The forecast module never opens scoring_targets.csv; its pure reference-prediction function accepts only conditionmetadata, frozenpredictions, fouranchorvalues and the original98-only slope.
