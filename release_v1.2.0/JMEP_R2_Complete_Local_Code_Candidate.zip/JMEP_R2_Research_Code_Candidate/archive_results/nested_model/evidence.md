# Bounded nested feasibility results

Completed locally on 5 November 2026. No publication or external repository change was performed. This is a retrospective development feasibility study on an already inspected primary cohort, not independent confirmation.

## Frozen design

All 98 source-checked condition summaries are retained. Existing publication/research-line groups define eight outer leave-group-out partitions. Targets have 44 YS, 98 UTS and 86 EL labels. YS and EL occur in seven of the groups, giving 22 target-specific outer evaluations. No outcome-based exclusion or label imputation is performed.

The candidate grid was frozen before this local refit: 32/45/53 inputs crossed with Ridge alpha 10/100/1000, ExtraTrees500 with leaf1/3 and max_features0.5, and RBF-SVR C1/10 with epsilon0.05 and gamma scale. Inner GroupKFold3 uses outer-training rows only. Minimum equal-source macro inner OOF MAE selects the candidate; pooled inner MAE is retained but not selected. Lexicographic candidate-ID ties are fixed. All imputation/scaling is fitted inside its training partition. No candidates were added or removed after these results.

The primary comparator is joint nested representation/learner selection. Representation-specific nested selections are secondary. Training mean, fixed raw32 Ridge100, and fixed aug45 ET500/leaf1 are the frozen controls. A separate chemistry18 Ridge10 comparator was requested after related project development findings and implemented after the present nested run, before additional external predictions. It is not a nested-grid candidate and is not a fresh preregistered hypothesis. Its unfavorable results are retained.

## Complete comparison

Each triplet follows YS / UTS / EL. Strength MAE is MPa; EL MAE is percentage points. Macro MAE weights each evaluated publication/research-line group equally.

| Comparator | Pooled R² | Pooled MAE | Equal-source macro MAE | Physical-invalid predictions |
|---|---|---|---|---|
| training_mean | -0.164 / -0.285 / -0.224 | 98.649 / 92.250 / 4.005 | 129.487 / 97.312 / 4.373 | 0 / 0 / 0 |
| ridge100_raw32 | -0.394 / -0.528 / -0.834 | 117.469 / 100.404 / 4.179 | 129.675 / 93.263 / 4.886 | 0 / 0 / 10 |
| fixed_ET45 | 0.061 / -0.301 / -0.262 | 93.905 / 88.357 / 3.689 | 121.509 / 93.478 / 3.233 | 0 / 0 / 0 |
| nested_joint | 0.136 / -0.599 / -0.439 | 78.409 / 97.475 / 3.903 | 116.752 / 96.556 / 4.620 | 0 / 0 / 0 |
| nested_raw32 | 0.144 / -0.750 / -0.036 | 77.583 / 108.130 / 3.156 | 115.192 / 117.223 / 3.654 | 0 / 0 / 0 |
| nested_aug45 | 0.187 / -0.538 / -0.402 | 78.353 / 96.201 / 3.899 | 112.729 / 98.139 / 3.701 | 0 / 0 / 0 |
| nested_state53 | 0.095 / -0.637 / -0.199 | 89.497 / 100.138 / 3.309 | 124.065 / 98.615 / 4.119 | 0 / 0 / 0 |
| chem18_ridge10 | -23.424 / -6.499 / -12.581 | 424.421 / 227.019 / 11.177 | 355.512 / 244.120 / 11.036 | 0 / 0 / 10 |

The primary nested joint procedure improves pooled YS MAE from98.649 to78.409MPa relative to the training mean, and source-macro YS MAE from129.487 to116.752MPa. Four of seven source groups improve relative to the mean; three worsen. Relative to fixedET45, its pooled YS MAE is better, but only three of seven source groups improve and four worsen. This is a limited descriptive YS improvement, not a universal or statistically established gain.

UTS remains poor under primary joint selection: pooled R²−0.599 and MAE97.475MPa, versus the training mean at92.250MPa and fixedET45 at88.357MPa. Its source-macro UTS MAE96.556MPa is close to the mean97.312MPa but worse than fixedET45 at93.478MPa. For EL, primary joint selection has slightly lower pooled MAE than the mean,3.903 versus4.005points, but higher equal-source macro error,4.620 versus4.373points; it is worse than fixedET45 by both summaries. The nested53-only comparator does not consistently outperform its alternatives. These results do not support a claim of reliable high-accuracy cross-study prediction, a generic feature gain, or a novel superior algorithm.

The separate chemistry18 Ridge10 control is severely unstable on this98-row cohort, with ten negative EL predictions. Independent sklearn imputer/scaler/target-transformer pipelines reproduce it; its failure was not corrected by clipping. Its results differ from a previously reported composition-only108-row development experiment; differences in row population, feature specification, missingness and partitions must be reconciled before treating those studies as the same control.

Physical-invalid flags mean negative strength or EL outside0–100%. They are basic consistency diagnostics, not a complete engineering qualification criterion. No nested outer predictions trigger those simple flags, but that does not imply engineering validity. Fixed raw32 Ridge100 produces ten negative EL predictions. No prediction is clipped.

## Independent audit

The main refit takes171.5s and1487actual estimator fits, with30786inner predictions,462inner candidate scores and1596outer predictions. The audit reconstructs all choices from inner scores, checks all record IDs/labels/source separation and target coverage, recomputes source and pooled metrics, and independently reconstructs60Ridge/SVR pipeline predictions. Maximum pipeline discrepancy is2.615e-12. The fixedET45 outer reference matches the previous independent refit exactly. All three immutable input files retain their hashes.

## Full-cohort deployment freeze and external interface

The same21candidates and3source folds on all available primary labels select raw32 ET leaf3 forYS, aug45 Ridge1000 forUTS, and aug45 Ridge100 forEL. These choices are frozen before additional external predictions. Their inner scores are selection diagnostics, not independent performance estimates. All4788full-source inner predictions and63candidate scores independently reconcile.

Model object SHA-256: be65c96ea0aefc751270c2c4d645e5f9db33eee01bd6c21b8885f49098f645a4. Selection SHA-256: c227b7a6f43f8931e5556fc5ac39ea5a57c3b265b2c98cac287025b8f9a86260.

External prediction accepts no outcome for selection. Both matrices must contain matching unique record_id and source-compatible45/53column names. Raw32 and chemistry18 are extracted from the45matrix. Output includes nested_joint, chemistry18 Ridge10, fixedET45, raw32 Ridge100 and training-mean predictions for all three targets. No external result chooses a model or revises the grid.

```text
python nested_publication_selection.py --source PATH_TO_ORIGINAL_RELEASE --out NEW_DIR --prepare
python nested_publication_selection.py --source PATH_TO_ORIGINAL_RELEASE --out NEW_DIR --run
python audit_nested_selection.py --source PATH_TO_ORIGINAL_RELEASE --out NEW_DIR
python freeze_deployment.py --source PATH_TO_ORIGINAL_RELEASE --out NEW_DIR --freeze
python freeze_deployment.py --out NEW_DIR --matrix45 EXTERNAL_45.csv --matrix53 EXTERNAL_53.csv --predictions EXTERNAL_PREDICTIONS.csv
```

Callable API: import freeze_deployment; freeze_deployment.predict(df45,df53,nested_dir=Path(LOCKED_MODEL_DIRECTORY)). It returns predictions without fitting. Required scientific dependencies match the study pinned environment.

## Interpretation limit

These publication holdouts and this cohort were examined repeatedly elsewhere in the overarching project. A locally frozen nested search reduces current fold-level selection leakage but does not undo analyst adaptation or turn the cohort into an untouched test. The new external sources must be transparently described as retrospective challenges with their own prior-discovery history. The present bounded study should not be expanded until a favorable metric appears.
