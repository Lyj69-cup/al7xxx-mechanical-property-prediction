"""Recompute the numerical revision candidate without network or model pickles."""
from pathlib import Path
import argparse, hashlib, importlib.metadata, itertools, json, sys

ROOT = Path(__file__).resolve().parent
# The packaged runner relies only on installed requirements. This optional
# environment hook helps an author reuse an existing pinned environment without
# distributing that environment in the archive.
import os
if os.environ.get('JMEP_PINNED_DEPS'):
    sys.path.insert(0, os.environ['JMEP_PINNED_DEPS'])
sys.path.insert(0, str(ROOT / 'src'))
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
from sklearn.compose import TransformedTargetRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import ExtraTreesRegressor
from features import features

OUT = ROOT / 'recomputed'
ARCH = ROOT / 'archive_results'
BASE = ROOT / 'input_base/data'
TARGETS = ['YS_MPa','UTS_MPa','EL_pct']
KEYS = ['record_id','source_id'] + TARGETS
TOL = 1e-7
checks = {}


def frame(path):
    return pd.read_csv(path)


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def save(df, name):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def verify_manifest():
    count = 0
    for line in (ROOT / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        h, name = line.split('  ', 1)
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == h, name
        count += 1
    checks['immutable_manifest_files'] = count


def compare(actual, expected_path, keys, columns, label):
    expected = frame(expected_path)
    assert not actual.duplicated(keys).any(), label
    assert not expected.duplicated(keys).any(), label
    a = actual.set_index(keys).sort_index()
    b = expected.set_index(keys).sort_index()
    assert a.index.equals(b.index), label
    maxdiff = 0.
    for c in columns:
        av = a[c].to_numpy(float); bv = b[c].to_numpy(float)
        assert np.array_equal(np.isnan(av), np.isnan(bv)), (label,c)
        valid = np.isfinite(av) & np.isfinite(bv)
        if valid.any():
            diff = float(np.max(np.abs(av[valid] - bv[valid])))
            assert diff < TOL, (label,c,diff)
            maxdiff = max(maxdiff, diff)
    checks[label] = dict(rows=len(a), max_abs_difference=maxdiff)


def audit_features():
    extra = None
    sets = [
        (BASE / 'primary_traceable.csv', BASE / 'primary_model_matrix_45.csv',
         BASE / 'primary_state_enriched.csv', BASE / 'primary_model_matrix_53.csv', 'primary'),
        (ROOT / 'input_external/external_condition_ledger.csv', ROOT / 'input_external/external_matrix_45.csv',
         ROOT / 'input_external/external_condition_ledger.csv', ROOT / 'input_external/external_matrix_53.csv', 'external'),
        (ROOT / 'input_followup/condition_ledger.csv', ROOT / 'input_followup/followup_matrix_45.csv',
         ROOT / 'input_followup/condition_ledger.csv', ROOT / 'input_followup/followup_matrix_53.csv', 'followup')]
    for ledgerpath, a45path, statepath, a53path, label in sets:
        ledger = frame(ledgerpath).fillna({'aging_stages':'','special_process':''})
        state = frame(statepath)
        a45 = frame(a45path); a53 = frame(a53path)
        c45 = [c for c in a45 if c not in KEYS]
        c53 = [c for c in a53 if c not in KEYS]
        x = features(ledger)
        assert list(x.columns) == c45 and len(c45) == 45 and len(c53) == 53
        assert set(TARGETS).isdisjoint(x.columns)
        np.testing.assert_allclose(x.to_numpy(float), a45[c45].to_numpy(float), atol=1e-12, rtol=0, equal_nan=True)
        enriched = pd.concat([x,state[c53[45:]]],axis=1)
        np.testing.assert_allclose(enriched.to_numpy(float), a53[c53].to_numpy(float), atol=1e-12, rtol=0, equal_nan=True)
        save(pd.concat([ledger[['record_id','source_id']],x],axis=1), f'features/{label}_45.csv')
        save(pd.concat([ledger[['record_id','source_id']],enriched],axis=1), f'features/{label}_53.csv')
        checks['feature_recreation_' + label] = dict(rows=len(x), predictors=53, missing_unknowns_preserved=True)
        extra = c53[45:]
    return extra


def fit_frozen_models():
    d = frame(BASE / 'primary_traceable.csv')
    a = frame(BASE / 'primary_model_matrix_45.csv')
    b = frame(BASE / 'primary_model_matrix_53.csv')
    c45 = [c for c in a if c not in KEYS]; c53 = [c for c in b if c not in KEYS]
    cols = {'raw32':c45[:32], 'aug45':c45, 'state53':c53, 'chem18':c45[:18]}
    plans = json.loads((ARCH / 'nested_model/frozen_plan.json').read_text(encoding='utf-8'))
    selection = json.loads((ARCH / 'nested_model/deployment_selection.json').read_text(encoding='utf-8'))['selection']
    candidates = {c['id']:c for c in plans['candidates']}
    result = {}
    for target in TARGETS:
        y = d[target].to_numpy(float); obs = np.flatnonzero(np.isfinite(y))
        main = candidates[selection[target]['candidate_id']]
        tasks = {'nested_joint':main,
                 'ridge100_raw32':dict(family='ridge',representation='raw32',alpha=100),
                 'fixed_ET45':dict(family='ET',representation='aug45',n_estimators=500,max_features=.5,min_samples_leaf=1,random_state=42,n_jobs=1),
                 'chem18_ridge10':dict(family='ridge',representation='chem18',alpha=10)}
        group = {}
        for name, c in tasks.items():
            estimator = Ridge if c['family'] == 'ridge' else ExtraTreesRegressor
            params = {k:v for k,v in c.items() if k not in {'id','family','representation'}}
            pipe = TransformedTargetRegressor(regressor=make_pipeline(SimpleImputer(strategy='median',keep_empty_features=True), StandardScaler(),estimator(**params)),transformer=StandardScaler())
            cc = cols[c['representation']]
            train = b if c['representation'] == 'state53' else a
            pipe.fit(train.loc[obs,cc].to_numpy(float), y[obs])
            group[name] = dict(estimator=pipe,columns=cc,representation=c['representation'])
        group['training_mean'] = dict(constant=float(np.mean(y[obs])))
        result[target] = group
        print('REFITTED', target, selection[target]['candidate_id'], flush=True)
    checks['frozen_full_source_pipelines_refitted'] = 12
    return result


def forecast(models, a45path, a53path):
    a = frame(a45path).set_index('record_id'); b = frame(a53path).set_index('record_id')
    assert a.index.equals(b.index) and a.index.is_unique
    rows=[]
    for target, dd in models.items():
        for name,m in dd.items():
            if name == 'training_mean':
                p = np.repeat(m['constant'], len(a))
            else:
                source = b if m['representation'] == 'state53' else a
                p = m['estimator'].predict(source[m['columns']].to_numpy(float))
            for rid,value in zip(a.index,p):
                rows.append(dict(record_id=rid,target=target,model=name,predicted=float(value),physical_invalid=bool(value<0 or(target=='EL_pct' and value>100))))
    return pd.DataFrame(rows)


def metric(y,p):
    y=np.asarray(y,float);p=np.asarray(p,float);e=p-y
    den=np.sum((y-y.mean())**2)
    return dict(n=len(y),R2=float(1-np.sum(e**2)/den) if len(y)>1 and den>0 else np.nan,
                MAE=float(np.mean(np.abs(e))),RMSE=float(np.sqrt(np.mean(e**2))),bias=float(e.mean()))


def summarize(q, keys):
    rows=[]
    for kk,g in q.groupby(keys):
        if len(keys)==1: kk=(kk,) if not isinstance(kk,tuple) else kk
        rows.append(dict(zip(keys,kk),**metric(g.observed,g.predicted)))
    return pd.DataFrame(rows)


def external(models):
    p=forecast(models,ROOT/'input_external/external_matrix_45.csv', ROOT/'input_external/external_matrix_53.csv')
    compare(p, ARCH/'external/predictions_frozen.csv',['record_id','target','model'],['predicted'],'external_zero_shot')
    save(p,'external/predictions.csv')
    truth=frame(ROOT/'input_external/external_target_ledger.csv')
    long=truth.melt(id_vars=['record_id','source_id','evaluation_stratum','original_condition'],value_vars=TARGETS,var_name='target',value_name='observed')
    q=p.merge(long,on=['record_id','target'],validate='many_to_one').dropna(subset=['observed'])
    q['error']=q.predicted-q.observed
    for keys,name in [(['source_id','evaluation_stratum','target','model'],'stratum'),(['source_id','target','model'],'source')]:
        m=summarize(q,keys)
        compare(m, ARCH/f'external/metrics_by_{name}.csv',keys,['MAE','RMSE','R2','bias'],f'external_{name}_metrics')
        save(m,f'external/metrics_by_{name}.csv')
    # Support and discrete condition choice remain visible rather than selecting
    # the favorable study or discarding physically inconsistent predictions.
    wide=p.pivot(index=['record_id','model'],columns='target',values='predicted')
    bad=wide[wide.YS_MPa>wide.UTS_MPa].reset_index()
    save(bad,'external/predicted_YS_above_UTS.csv')
    assert len(bad)==8
    checks['external_physical_order_violations_retained']=len(bad)
    choices=[]
    from scipy.stats import spearmanr
    import warnings
    for sid in ['HE2025','JIANG_AMS2026']:
        for model,g in q[(q.source_id==sid)&(q.target=='UTS_MPa')].groupby('model'):
            selected=g[np.isclose(g.predicted,g.predicted.max(),atol=1e-10,rtol=0)]
            best=float(g.observed.max());regrets=best-selected.observed
            obs=truth.set_index('record_id').loc[selected.record_id]
            with warnings.catch_warnings():
                warnings.simplefilter('ignore'); rho=float(spearmanr(g.observed,g.predicted).statistic) if g.predicted.nunique()>1 else np.nan
            pairs=[]
            for (_,a),(_,b) in itertools.combinations(g.iterrows(),2):
                dy=a.observed-b.observed;dp=a.predicted-b.predicted
                if dy!=0:pairs.append(.5 if abs(dp)<1e-10 else float(dy*dp>0))
            choices.append(dict(source_id=sid,model=model,n_conditions=len(g),observed_best_UTS_MPa=best,
                n_highest_prediction_ties=len(selected),best_case_UTS_regret_MPa=float(regrets.min()),worst_case_UTS_regret_MPa=float(regrets.max()),
                selected_EL_min_pct=float(obs.EL_pct.min()),selected_EL_max_pct=float(obs.EL_pct.max()),Spearman=rho,pairwise_concordance=float(np.mean(pairs))))
    choice=pd.DataFrame(choices)
    compare(choice,ARCH/'external/engineering_condition_selection.csv',['source_id','model'],['n_conditions','observed_best_UTS_MPa','n_highest_prediction_ties','best_case_UTS_regret_MPa','worst_case_UTS_regret_MPa','selected_EL_min_pct','selected_EL_max_pct','Spearman','pairwise_concordance'],'external_condition_choice')
    save(choice,'external/engineering_condition_selection.csv')
    return p


def training_slopes():
    d=frame(BASE/'primary_state_enriched.csv'); x=frame(BASE/'primary_model_matrix_53.csv')
    cc=[c for c in x if c not in KEYS]
    groupcols=[c for c in cc[:32] if c!='aging_time_h']+cc[-8:]
    keys=[(str(s),tuple(None if pd.isna(v) else float(v) for v in row)) for s,row in zip(d.source_id,x[groupcols].to_numpy())]
    beta={}; training=[]
    for target in TARGETS:
        grouped={}
        for i,k in enumerate(keys):
            if np.isfinite(d.at[i,'aging_time_h']) and d.at[i,'aging_time_h']>0 and np.isfinite(d.at[i,target]):grouped.setdefault(k,[]).append(i)
        rows=[]
        for (sid,_), ids in grouped.items():
            if len(ids)<2 or d.loc[ids,'aging_time_h'].nunique()<2:continue
            t=np.log1p(d.loc[ids,'aging_time_h'].to_numpy(float));y=d.loc[ids,target].to_numpy(float)
            for i,dt,dy in zip(ids,t-t.mean(),y-y.mean()):rows.append(dict(record_id=d.at[i,'record_id'],source_id=sid,target=target,centered_log_time=dt,centered_target=dy))
        q=pd.DataFrame(rows);q['source_weight']=1/q.groupby('source_id').record_id.transform('count')
        den=float(np.sum(q.source_weight*q.centered_log_time**2));coef=float(np.sum(q.source_weight*q.centered_log_time*q.centered_target)/den)
        beta[target]=dict(slope=coef,training_rows=len(q),training_sources=int(q.source_id.nunique()),denominator=den)
        training.extend(q.to_dict('records'))
    expected=json.loads((ARCH/'one_reference/simple_slope_coefficients.json').read_text(encoding='utf-8'))
    assert all(abs(beta[t]['slope']-expected[t]['slope'])<TOL for t in TARGETS)
    save(pd.DataFrame(training),'one_reference/simple_slope_training.csv')
    dump(OUT/'one_reference/simple_slope_coefficients.json',beta)
    checks['original98_only_slopes_reproduced']=beta
    return beta


def development_reference(zero,beta):
    d=frame(ROOT/'input_external/external_target_ledger.csv')
    meta=frame(ROOT/'input_external/external_condition_ledger.csv').set_index('record_id')
    plan=json.loads((ARCH/'one_reference/frozen_reference_plan.json').read_text(encoding='utf-8'))
    zz=zero.set_index(['record_id','target','model']);rows=[]
    for sid,s in plan['sources'].items():
        aid=s['anchor_record']; anchor=d.set_index('record_id').loc[aid]
        query=d[(d.source_id==sid)&(d.record_id!=aid)]
        for target in TARGETS:
            ya=float(anchor[target])
            if not np.isfinite(ya):continue
            for rid in query.record_id:
                values={'anchor_constant':ya,'anchor_plus_simple_logtime':ya+beta[target]['slope']*(np.log1p(meta.at[rid,'aging_time_h'])-np.log1p(meta.at[aid,'aging_time_h']))}
                for model in zero.model.unique():
                    pq=float(zz.at[(rid,target,model),'predicted']);pa=float(zz.at[(aid,target,model),'predicted'])
                    values['zero_shot__'+model]=pq;values['anchor_offset__'+model]=ya+pq-pa
                for method,p in values.items():rows.append(dict(record_id=rid,source_id=sid,target=target,method=method,predicted=p,anchor_record=aid))
    p=pd.DataFrame(rows)
    compare(p,ARCH/'one_reference/predictions_before_scoring.csv',['record_id','target','method'],['predicted'],'development_reference_forecasts')
    save(p,'one_reference/predictions_before_scoring.csv')
    truth=d.melt(id_vars=['record_id','source_id'],value_vars=TARGETS,var_name='target',value_name='observed')
    q=p.merge(truth,on=['record_id','source_id','target'],validate='many_to_one').dropna(subset=['observed'])
    m=summarize(q,['source_id','target','method'])
    compare(m,ARCH/'one_reference/metrics.csv',['source_id','target','method'],['MAE','RMSE','bias'],'development_reference_metrics')
    save(m,'one_reference/metrics.csv')


def readout_bounds(e,a,b):
    # Independent scalar optimizer cross-check accompanies the exact convex
    # piecewise-linear knots; these are allowance extrema, not statistical CIs.
    e=np.asarray(e,float);b=np.asarray(b,float)
    knots=np.unique(np.r_[[-a,a],np.clip(-e-b,-a,a),np.clip(-e+b,-a,a)])
    objective=lambda delta:float(np.maximum(np.abs(e+delta)-b,0).mean())
    lo=min(map(objective,knots));hi=max(float(np.abs(e-a).mean()),float(np.abs(e+a).mean()))+float(b.mean())
    if a>0:
        opt=minimize_scalar(objective,bounds=(-a,a),method='bounded',options={'xatol':1e-12})
        assert abs(min(objective(-a),objective(a),float(opt.fun))-lo)<1e-7
    return lo,hi


def followup(models,beta):
    zero=forecast(models,ROOT/'input_followup/followup_matrix_45.csv',ROOT/'input_followup/followup_matrix_53.csv').query("target=='UTS_MPa'").copy()
    compare(zero,ARCH/'reference_followup/zero_shot_all_conditions.csv',['record_id','target','model'],['predicted'],'followup_zero_shot')
    save(zero,'followup/zero_shot_all_conditions.csv')
    # Forecast inputs have no query-label argument. Only the four declared
    # reference values are passed as labels to this arithmetic.
    meta=frame(ROOT/'input_followup/condition_ledger.csv')[['record_id','source_id','series_id','aging_time_h','is_anchor','anchor_record']]
    anchors=frame(ROOT/'input_followup/consumed_anchors.csv').set_index('record_id')
    assert len(anchors)==4 and anchors.is_anchor.all()
    zz=zero.set_index(['record_id','model']);rows=[]
    for r in meta.itertuples():
        if r.is_anchor:continue
        anchor=anchors.loc[r.anchor_record];ya=float(anchor.observed)
        values={'anchor_constant':ya,'anchor_plus_fixed_source_logtime_slope':ya+beta['UTS_MPa']['slope']*(np.log1p(r.aging_time_h)-np.log1p(anchor.aging_time_h))}
        for model in zero.model.unique():
            pq=float(zz.at[(r.record_id,model),'predicted']);pa=float(zz.at[(r.anchor_record,model),'predicted'])
            values['zero_shot__'+model]=pq;values['anchor_offset__'+model]=ya+pq-pa
        for method,p in values.items():rows.append(dict(record_id=r.record_id,source_id=r.source_id,series_id=r.series_id,target='UTS_MPa',method=method,predicted=p,anchor_record=r.anchor_record))
    p=pd.DataFrame(rows)
    compare(p,ARCH/'reference_followup/predictions_before_scoring.csv',['record_id','method'],['predicted'],'followup_reference_forecasts')
    save(p,'followup/predictions_before_scoring.csv')
    # Query targets are first opened after the forecasts above are written.
    target=frame(ROOT/'input_followup/scoring_targets.csv'); query=target[~target.is_anchor].copy()
    q=p.merge(query[['record_id','observed','reading_half_range_MPa']],on='record_id',validate='many_to_one');q['error']=q.predicted-q.observed
    series=[]
    for kk,g in q.groupby(['series_id','source_id','method']):
        sid,pub,method=kk;a=0. if method.startswith('zero_shot__') else float(anchors.at[g.anchor_record.iloc[0],'reading_half_range_MPa'])
        lo,hi=readout_bounds(g.error,a,g.reading_half_range_MPa)
        series.append(dict(series_id=sid,source_id=pub,method=method,**metric(g.observed,g.predicted),conditional_readout_MAE_best=lo,conditional_readout_MAE_worst=hi,anchor_allowance_MPa=a,query_allowance_MPa=float(g.reading_half_range_MPa.iloc[0])))
    sm=pd.DataFrame(series)
    compare(sm,ARCH/'reference_followup/metrics_by_series.csv',['series_id','method'],['MAE','RMSE','R2','bias','conditional_readout_MAE_best','conditional_readout_MAE_worst'],'followup_series_metrics_and_readout')
    save(sm,'followup/metrics_by_series.csv')
    source=[]
    for (sid,method),g in q.groupby(['source_id','method']):
        s=sm[(sm.source_id==sid)&(sm.method==method)]
        source.append(dict(source_id=sid,method=method,**metric(g.observed,g.predicted),conditional_readout_MAE_best=float(np.average(s.conditional_readout_MAE_best,weights=s.n)),conditional_readout_MAE_worst=float(np.average(s.conditional_readout_MAE_worst,weights=s.n))))
    so=pd.DataFrame(source)
    compare(so,ARCH/'reference_followup/metrics_by_source.csv',['source_id','method'],['MAE','RMSE','conditional_readout_MAE_best','conditional_readout_MAE_worst'],'followup_source_metrics')
    save(so,'followup/metrics_by_source.csv')
    summary=[]
    for method,g in q.groupby('method'):
        ss=so[so.method==method];s=sm[sm.method==method]
        summary.append(dict(method=method,query_n=len(g),pooled_MAE=float(np.abs(g.error).mean()),pooled_RMSE=float(np.sqrt(np.mean(g.error**2))),macro_source_MAE=float(ss.MAE.mean()),macro_series_MAE=float(s.MAE.mean()),conditional_readout_MAE_best=float(np.average(s.conditional_readout_MAE_best,weights=s.n)),conditional_readout_MAE_worst=float(np.average(s.conditional_readout_MAE_worst,weights=s.n))))
    summary=pd.DataFrame(summary)
    compare(summary,ARCH/'reference_followup/metrics_summary.csv',['method'],['pooled_MAE','pooled_RMSE','macro_source_MAE','macro_series_MAE','conditional_readout_MAE_best','conditional_readout_MAE_worst'],'followup_all_method_summary')
    save(summary,'followup/metrics_summary.csv')
    gain=[]
    for sid,g in sm.groupby('series_id'):
        baseline=g[g.method=='anchor_constant'].iloc[0]
        for r in g[~g.method.str.startswith('zero_shot__')].itertuples():
            gain.append(dict(series_id=sid,method=r.method,nominal_MAE_gain_vs_anchor_constant=float(baseline.MAE-r.MAE),conservative_gain_lower=float(baseline.conditional_readout_MAE_best-r.conditional_readout_MAE_worst),conservative_gain_upper=float(baseline.conditional_readout_MAE_worst-r.conditional_readout_MAE_best)))
    gain=pd.DataFrame(gain)
    compare(gain,ARCH/'reference_followup/paired_gain_readout_sensitivity.csv',['series_id','method'],['nominal_MAE_gain_vs_anchor_constant','conservative_gain_lower','conservative_gain_upper'],'followup_gain_sensitivity')
    save(gain,'followup/paired_gain_readout_sensitivity.csv')


def state_minimum(extra):
    a=frame(BASE/'primary_model_matrix_45.csv');b=frame(BASE/'primary_model_matrix_53.csv')
    cols=[c for c in a if c not in KEYS]; groups={}
    for i,row in a[cols].iterrows():groups.setdefault(tuple(None if pd.isna(v) else float(v) for v in row),[]).append(i)
    pairs=[]
    for ids in groups.values():
        for i,j in itertools.combinations(ids,2):
            differences=[c for c in extra if pd.notna(b.at[i,c]) and pd.notna(b.at[j,c]) and b.at[i,c]!=b.at[j,c]]
            pairs.append(dict(record_a=a.at[i,'record_id'],record_b=a.at[j,'record_id'],fields=differences))
    assert len(pairs)==15
    sets=[]
    for k in range(9):
        for sub in itertools.combinations(extra,k):sets.append(dict(fields=list(sub),n_fields=k,covered=sum(bool(set(sub)&set(p['fields'])) for p in pairs)))
    full=[s for s in sets if s['covered']==15];minimum=min(s['n_fields'] for s in full);minsets=[s['fields'] for s in full if s['n_fields']==minimum]
    expected=json.loads((ARCH/'diagnostic_design/state_requirement_audit.json').read_text(encoding='utf-8'))
    assert minimum==7 and minsets==[r['fields'] for r in expected['all_minimum_jointly_observed_sets']]
    assert len(sets)==256 and all(p['fields'] for p in pairs)
    dump(OUT/'diagnostic_design/reproduction.json',dict(pairs=pairs,subsets=sets,minimum_fields=minimum,minimum_sets=minsets))
    checks['finite_sample_state_requirements']=dict(pairs=15,subsets=256,unique_minimum=minimum,universal_requirement_claimed=False)


def optional_nested():
    import nested_publication_selection as n
    import freeze_deployment as f
    nested=OUT/'nested_model';nested.mkdir(exist_ok=True)
    import shutil
    for name in ['frozen_plan.json','frozen_plan_sha256.json']:
        shutil.copy2(ARCH/'nested_model'/name,nested/name)
    n.run(ROOT/'input_base',nested)
    pred=frame(nested/'outer_predictions.csv')
    compare(pred,ARCH/'nested_model/outer_predictions.csv',['outer_group','record_id','target','model'],['predicted'],'complete_nested_outer_predictions')
    choices=frame(nested/'outer_choices.csv').set_index(['outer_group','target','model']).selected_candidate.sort_index()
    old=frame(ARCH/'nested_model/outer_choices.csv').set_index(['outer_group','target','model']).selected_candidate.sort_index()
    assert choices.equals(old)
    f.freeze(ROOT/'input_base',nested)
    new=json.loads((nested/'deployment_selection.json').read_text(encoding='utf-8'))['selection']
    old=json.loads((ARCH/'nested_model/deployment_selection.json').read_text(encoding='utf-8'))['selection']
    assert all(new[t]['candidate_id']==old[t]['candidate_id'] for t in TARGETS)
    checks['complete_grid_and_deployment_choices_reproduced']=True


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--nested',action='store_true');args=ap.parse_args()
    verify_manifest();OUT.mkdir(exist_ok=True)
    extra=audit_features();models=fit_frozen_models();zero=external(models)
    beta=training_slopes();development_reference(zero,beta);followup(models,beta);state_minimum(extra)
    if args.nested:optional_nested()
    report=dict(status='PASS',mode='full_nested_plus_default' if args.nested else 'refit_frozen_deployment_and_recompute',
                tolerance=TOL,checks=checks,dependencies={k:importlib.metadata.version(k) for k in ['numpy','pandas','scipy','scikit-learn','joblib']},
                no_network=True,no_query_target_model_selection=True,no_model_pickle_loaded=True,
                prior_exposure_disclosed=True,publication_allowed=False,
                limitations=['Reproduction starts from qualified curated numeric ledgers, not automatic full-text extraction.',
                             'Readout allowances are conditional sensitivity assumptions, not SDs or confidence intervals.',
                             'The reference follow-up is retrospective and posthoc-origin, not blinded or preregistered.',
                             'Default mode reuses recorded deployment choices; --nested recomputes the complete frozen choices.'])
    dump(OUT/'portable_reproduction_check.json',report)
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
