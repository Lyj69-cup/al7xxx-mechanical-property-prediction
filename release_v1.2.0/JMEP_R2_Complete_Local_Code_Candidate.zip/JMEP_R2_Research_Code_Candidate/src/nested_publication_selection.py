"""Bounded retrospective nested selection on all 98 primary condition summaries.

The source groups/data were examined elsewhere in the overarching project.
Freezing this local candidate list before refitting does NOT create untouched
external validation or undo historical analyst adaptation.
"""
from __future__ import annotations
import argparse,hashlib,importlib.metadata,json,math,sys,time,warnings
from pathlib import Path

DEFAULT=Path(__file__).resolve().parents[2]
if (DEFAULT/'pydeps').is_dir():sys.path.insert(0,str(DEFAULT/'pydeps'))
import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.linear_model import Ridge
from sklearn.svm import SVR
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score

TARGETS=['YS_MPa','UTS_MPa','EL_pct']
FILES=['data/primary_traceable.csv','data/primary_model_matrix_45.csv','data/primary_model_matrix_53.csv']
KEYS=['record_id','source_id']+TARGETS
REP=['raw32','aug45','state53']
MODELS=['training_mean','ridge100_raw32','fixed_ET45','nested_joint','nested_raw32','nested_aug45','nested_state53']

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def candidates():
 out=[]
 for rep in REP:
  for a in [10,100,1000]:out.append(dict(id=f'{rep}__ridge_{a}',representation=rep,family='ridge',alpha=a))
  for leaf in [1,3]:out.append(dict(id=f'{rep}__ET_leaf{leaf}',representation=rep,family='ET',n_estimators=500,max_features=.5,min_samples_leaf=leaf,random_state=42,n_jobs=1))
  for c in [1,10]:out.append(dict(id=f'{rep}__SVR_C{c}',representation=rep,family='SVR',C=c,gamma='scale',epsilon=.05))
 return sorted(out,key=lambda x:x['id'])

def load(source):
 d=pd.read_csv(source/FILES[0]);a=pd.read_csv(source/FILES[1]);b=pd.read_csv(source/FILES[2])
 assert len(d)==len(a)==len(b)==98 and d.record_id.is_unique and d.study_group.nunique()==8
 assert (d.record_id==a.record_id).all() and (d.record_id==b.record_id).all()
 c45=[c for c in a if c not in KEYS];c53=[c for c in b if c not in KEYS]
 assert len(c45)==45 and len(c53)==53 and c53[:45]==c45
 for t in TARGETS:
  np.testing.assert_equal(d[t].to_numpy(),a[t].to_numpy());np.testing.assert_equal(d[t].to_numpy(),b[t].to_numpy())
 np.testing.assert_equal(a[c45].to_numpy(),b[c45].to_numpy())
 return d,{'raw32':a[c45[:32]].to_numpy(float),'aug45':a[c45].to_numpy(float),'state53':b[c53].to_numpy(float)}, {'raw32':c45[:32],'aug45':c45,'state53':c53}

def make_folds(d):
 groups=d.study_group.to_numpy();folds=[];skipped=[]
 for outer in sorted(d.study_group.unique()):
  for target in TARGETS:
   obs=d[target].notna().to_numpy();tr=np.flatnonzero((groups!=outer)&obs);te=np.flatnonzero((groups==outer)&obs)
   if not len(te):skipped.append(dict(outer_group=outer,target=target,reason='No observed target in held-out group'));continue
   assert len(tr)>1 and set(groups[tr]).isdisjoint(groups[te])
   ninner=min(3,len(np.unique(groups[tr])))
   assert ninner>=2
   inner=[]
   for k,(aa,bb) in enumerate(GroupKFold(ninner).split(tr,groups=groups[tr])):
    it,iv=tr[aa],tr[bb];assert set(groups[it]).isdisjoint(groups[iv])
    inner.append(dict(inner_fold=k,training_ids=d.iloc[it].record_id.tolist(),validation_ids=d.iloc[iv].record_id.tolist(),training_groups=sorted(set(groups[it])),validation_groups=sorted(set(groups[iv]))))
   folds.append(dict(outer_group=outer,target=target,training_ids=d.iloc[tr].record_id.tolist(),testing_ids=d.iloc[te].record_id.tolist(),training_groups=sorted(set(groups[tr])),testing_groups=[outer],inner=inner))
 return folds,skipped

def prepare(source,out):
 out.mkdir(parents=True,exist_ok=True);d,x,columns=load(source);folds,skipped=make_folds(d)
 plan=dict(date_client='2026-11-05',status='FROZEN_BEFORE_CURRENT_REFITS',retrospective=True,preregistered=False,
  source_rows=98,publication_line_groups=8,label_counts={t:int(d[t].notna().sum()) for t in TARGETS},
  prior_project_adaptation='These cohorts and source holdouts were examined in earlier project analyses. This bounded refit is not an untouched external test and is not a first nested analysis of the broader project.',
  source_sha256={f:sha(source/f) for f in FILES},feature_columns=columns,candidates=candidates(),
  outer_protocol='Leave one of all eight existing publication/research-line groups out; no outcome-based row exclusion.',
  inner_protocol='Deterministic GroupKFold3 on observed-target outer-training rows only; source groups disjoint inside each fold.',
  selection_objective='Minimum equally weighted per-source inner out-of-fold MAE. Pooled inner MAE retained but not used. Exact ties broken by lexicographically smallest frozen candidate ID.',
  primary_comparator='nested_joint selects representation and learner entirely inside outer training.',secondary_comparators='Representation-specific nested selections are secondary, not independent replications. Fixed raw32 Ridge alpha100, training mean and fixed aug45 ET are retained.',
  preprocessing='Fit medians, all-training-missing constant0, predictor scaler and target scaler on each inner/outer training partition. No label imputation, post-outcome clipping or re-selection.',
  uncertainty='One retrospective complete outer holdout vector per target/model. Pooled and equal-source macro errors and every source error retained; no confirmatory significance claim.',
  no_adaptive_expansion='Candidate grid and eligible data will not be changed in response to these outer scores.',
  folds=folds,skipped_target_groups=skipped)
 p=out/'frozen_plan.json'
 if p.exists():
  old=json.loads(p.read_text(encoding='utf-8'));assert old==plan,'Existing frozen plan differs; do not overwrite it after examining results.'
 else:dump(p,plan)
 dump(out/'frozen_plan_sha256.json',{'sha256':sha(p)})
 print('PLAN_FROZEN',len(folds),'outer target folds',len(candidates()),'candidates',flush=True)

def process_fit(x,y):
 with warnings.catch_warnings():
  warnings.simplefilter('ignore',category=RuntimeWarning);med=np.nanmedian(x,axis=0)
 empty=np.flatnonzero(~np.isfinite(med));med[empty]=0.
 z=np.where(np.isnan(x),med,x);sx=StandardScaler().fit(z);sy=StandardScaler().fit(y.reshape(-1,1))
 return med,sx,sy,empty.tolist()
def tx(x,med,sx):return sx.transform(np.where(np.isnan(x),med,x))
def model(c):
 params={k:v for k,v in c.items() if k not in ['id','representation','family']}
 return {'ridge':Ridge,'ET':ExtraTreesRegressor,'SVR':SVR}[c['family']](**params)
def fit_predict(c,x,y,tr,te):
 med,sx,sy,empty=process_fit(x[tr],y[tr]);m=model(c);m.fit(tx(x[tr],med,sx),sy.transform(y[tr].reshape(-1,1)).ravel())
 p=sy.inverse_transform(np.asarray(m.predict(tx(x[te],med,sx))).reshape(-1,1)).ravel()
 assert np.isfinite(p).all()
 return p,empty
def met(y,p):
 return dict(n=len(y),R2=float(r2_score(y,p)) if len(y)>1 and np.ptp(y)>0 else None,
  RMSE=float(np.sqrt(mean_squared_error(y,p))),MAE=float(mean_absolute_error(y,p)),bias=float(np.mean(p-y)))

def run(source,out):
 begin=time.monotonic();plan=json.loads((out/'frozen_plan.json').read_text(encoding='utf-8'))
 assert all(sha(source/f)==h for f,h in plan['source_sha256'].items())
 assert sha(out/'frozen_plan.json')==json.loads((out/'frozen_plan_sha256.json').read_text())['sha256']
 d,x,columns=load(source);index={r:i for i,r in enumerate(d.record_id)};cand=plan['candidates'];cd={c['id']:c for c in cand}
 inner_predictions=[];scores=[];choices=[];outer_predictions=[];preprocess=[];fit_count=0
 for number,f in enumerate(plan['folds'],1):
  target=f['target'];outer=f['outer_group'];y=d[target].to_numpy(float)
  tr=np.array([index[r] for r in f['training_ids']]);te=np.array([index[r] for r in f['testing_ids']])
  local=[]
  for c in cand:
   cy=[];cp=[];cg=[]
   for inn in f['inner']:
    it=np.array([index[r] for r in inn['training_ids']]);iv=np.array([index[r] for r in inn['validation_ids']])
    p,empty=fit_predict(c,x[c['representation']],y,it,iv);fit_count+=1
    cy.extend(y[iv]);cp.extend(p);cg.extend(d.iloc[iv].study_group)
    preprocess.append(dict(outer_group=outer,target=target,phase='inner',fold=inn['inner_fold'],candidate_id=c['id'],n_train=len(it),n_test=len(iv),entirely_missing_training_fields=json.dumps([columns[c['representation']][j] for j in empty])))
    for i,pred in zip(iv,p):inner_predictions.append(dict(outer_group=outer,target=target,inner_fold=inn['inner_fold'],candidate_id=c['id'],record_id=d.at[i,'record_id'],source_group=d.at[i,'study_group'],observed=float(y[i]),predicted=float(pred)))
   a=pd.DataFrame({'y':cy,'p':cp,'g':cg});a['error']=(a.p-a.y).abs()
   row=dict(outer_group=outer,target=target,candidate_id=c['id'],representation=c['representation'],family=c['family'],inner_pooled_MAE=float(a.error.mean()),inner_macro_source_MAE=float(a.groupby('g').error.mean().mean()),n_inner_predictions=len(a),inner_sources=int(a.g.nunique()))
   local.append(row);scores.append(row)
  selected={'nested_joint':min(local,key=lambda z:(z['inner_macro_source_MAE'],z['candidate_id']))}
  for rep in REP:selected['nested_'+rep]=min([z for z in local if z['representation']==rep],key=lambda z:(z['inner_macro_source_MAE'],z['candidate_id']))
  selected['ridge100_raw32']={'candidate_id':'raw32__ridge_100'}
  selected['fixed_ET45']={'candidate_id':'aug45__ET_leaf1'}
  cache={}
  for name,s in selected.items():
   cid=s['candidate_id'];c=cd[cid]
   if cid not in cache:
    cache[cid],empty=fit_predict(c,x[c['representation']],y,tr,te);fit_count+=1
    preprocess.append(dict(outer_group=outer,target=target,phase='outer',fold=-1,candidate_id=cid,n_train=len(tr),n_test=len(te),entirely_missing_training_fields=json.dumps([columns[c['representation']][j] for j in empty])))
   p=cache[cid]
   choices.append(dict(outer_group=outer,target=target,model=name,selected_candidate=cid,representation=c['representation'],family=c['family'],inner_macro_source_MAE=s.get('inner_macro_source_MAE'),inner_pooled_MAE=s.get('inner_pooled_MAE'),training_n=len(tr),testing_n=len(te)))
   for i,pred in zip(te,p):outer_predictions.append(dict(outer_group=outer,target=target,model=name,record_id=d.at[i,'record_id'],source_id=d.at[i,'source_id'],observed=float(y[i]),predicted=float(pred),candidate_id=cid,physical_invalid=bool(pred<0 or (target=='EL_pct' and pred>100)),outside_training_target_range=bool(pred<np.min(y[tr]) or pred>np.max(y[tr]))))
  for i in te:
   pred=float(np.mean(y[tr]));outer_predictions.append(dict(outer_group=outer,target=target,model='training_mean',record_id=d.at[i,'record_id'],source_id=d.at[i,'source_id'],observed=float(y[i]),predicted=pred,candidate_id='training_mean',physical_invalid=False,outside_training_target_range=False))
  # Persist completed folds for review without silently accepting partial coverage.
  for filename,rows in [('inner_predictions.csv',inner_predictions),('inner_candidate_scores.csv',scores),('outer_choices.csv',choices),('outer_predictions.csv',outer_predictions),('preprocessing_log.csv',preprocess)]:pd.DataFrame(rows).to_csv(out/filename,index=False)
  print(f'NESTED {number}/{len(plan["folds"])} {outer} {target} complete {time.monotonic()-begin:.1f}s',flush=True)
 p=pd.DataFrame(outer_predictions);pm=[];pooled=[]
 for (m,t,g),q in p.groupby(['model','target','outer_group']):pm.append(dict(model=m,target=t,outer_group=g,**met(q.observed.to_numpy(),q.predicted.to_numpy())))
 gm=pd.DataFrame(pm);gm.to_csv(out/'metrics_per_source.csv',index=False)
 for (m,t),q in p.groupby(['model','target']):
  z=gm[(gm.model==m)&(gm.target==t)]
  pooled.append(dict(model=m,target=t,**met(q.observed.to_numpy(),q.predicted.to_numpy()),macro_source_MAE=float(z.MAE.mean()),macro_source_RMSE=float(z.RMSE.mean()),evaluated_source_groups=len(z),invalid_predictions=int(q.physical_invalid.sum()),outside_training_target_range=int(q.outside_training_target_range.sum())))
 pd.DataFrame(pooled).to_csv(out/'metrics_pooled.csv',index=False)
 contrasts=[]
 for challenger in ['nested_joint','nested_raw32','nested_aug45','nested_state53']:
  for baseline in ['training_mean','ridge100_raw32','fixed_ET45']:
   for target in TARGETS:
    aa=gm[(gm.model==challenger)&(gm.target==target)].set_index('outer_group');bb=gm[(gm.model==baseline)&(gm.target==target)].set_index('outer_group');delta=aa.MAE-bb.MAE
    contrasts.append(dict(challenger=challenger,baseline=baseline,target=target,n_groups=len(delta),macro_MAE_difference_challenger_minus_baseline=float(delta.mean()),groups_improved=int((delta<0).sum()),groups_worse=int((delta>0).sum()),groups_equal=int((delta==0).sum()),maximum_group_MAE_increase=float(delta.max()),minimum_group_MAE_difference=float(delta.min())))
 pd.DataFrame(contrasts).to_csv(out/'paired_source_differences.csv',index=False)
 dump(out/'execution_metadata.json',dict(status='COMPLETE',seconds=time.monotonic()-begin,fit_count=fit_count,inner_predictions=len(inner_predictions),outer_predictions=len(outer_predictions),outer_target_folds=len(plan['folds']),dependencies={n:importlib.metadata.version(n) for n in ['numpy','pandas','scipy','scikit-learn']},input_hashes_unchanged={f:sha(source/f)==h for f,h in plan['source_sha256'].items()},historically_reused_validation=True))
 print('NESTED_DONE',len(outer_predictions),'outer predictions',flush=True)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,default=DEFAULT/'github_submission_fix');ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parent);ap.add_argument('--prepare',action='store_true');ap.add_argument('--run',action='store_true');a=ap.parse_args()
 if a.prepare:prepare(a.source.resolve(),a.out.resolve())
 if a.run:run(a.source.resolve(),a.out.resolve())
