"""Same 32/45-field transform as the retained MIT-licensed source.

Extracted from review_v4.py/recompute_v4.py solely to remove unused model-library
imports. The actual category mappings and descriptor equations are unchanged.
"""
import json
import numpy as np
import pandas as pd
from scipy.special import logsumexp
COMP=['Zn','Mg','Cu','Mn','Cr','Zr','Fe','Si','Ti','Ni','Sc','Sr','Y','Er','Li','Ag','V','Ce']
PROC=['solution_temp_C','solution_time_h','aging_temp_C','aging_time_h','pre_deformation_pct']
TF=['tf_annealed','tf_natural','tf_artificial','tf_overaged','tf_unknown']
FF=['ff_extrusion','ff_forging','ff_castnearnet','ff_unknown']
DERIVED=['Zn_Mg_ratio','Zn_Mg_Cu_total','Mg_Cu_ratio','Zr_Mn_Cr_total',
 'Zn_Mg_product','solution_temp_time','has_deformation','aging_time_log',
 'Zn_aging_interaction','Mg_solution_interaction','alloy_agingtemp',
 'aging_kinetic_P','has_special_process']
def form_family(p):
    p = str(p).lower()
    if "extr" in p: return "ff_extrusion"
    if "forg" in p: return "ff_forging"
    if "cast" in p: return "ff_castnearnet"
    return "ff_unknown"

def temper(t):
    s=str(t).lower().strip()
    if 'over' in s:return 'tf_overaged'
    if 'natural' in s or 't4' in s:return 'tf_natural'
    if any(x in s for x in ['t6','peak','artificial','two-step','rra']):return 'tf_artificial'
    if s=='o' or 'anneal' in s:return 'tf_annealed'
    return 'tf_unknown'

def features(d,kind='phys',q=130000.):
    x=pd.DataFrame(index=d.index)
    for c in COMP+PROC:x[c]=pd.to_numeric(d[c],errors='coerce')
    tf=d.temper.map(temper); ff=d.product_form.map(form_family)
    for c in TF:x[c]=(tf==c).astype(float)
    for c in FF:x[c]=(ff==c).astype(float)
    cols=COMP+PROC+TF+FF
    if kind=='raw':return x[cols]
    zn,mg,cu=x.Zn,x.Mg,x.Cu
    x['Zn_Mg_ratio']=zn/(mg+.01);x['Zn_Mg_Cu_total']=zn+mg+cu
    x['Mg_Cu_ratio']=mg/(cu+.01);x['Zr_Mn_Cr_total']=x[['Zr','Mn','Cr']].sum(axis=1,min_count=3)
    x['Zn_Mg_product']=zn*mg
    x['solution_temp_time']=x.solution_temp_C*x.solution_time_h/100.
    x['has_deformation']=np.where(x.pre_deformation_pct.notna(),(x.pre_deformation_pct>0).astype(float),np.nan)
    positive=x.aging_time_h.where(x.aging_time_h>0)
    x['aging_time_log']=np.log1p(positive)
    x['Zn_aging_interaction']=zn*x.aging_temp_C/100.
    x['Mg_solution_interaction']=mg*x.solution_temp_C/100.
    x['alloy_agingtemp']=(zn+mg+cu)*x.aging_temp_C/100.
    def kinetic(row):
        stages=json.loads(row.aging_stages) if row.aging_stages else [[row.aging_temp_C,row.aging_time_h]]
        if not stages or any(not np.isfinite(t) or not np.isfinite(h) or t<=-273.15 or h<=0 for t,h in stages):return np.nan
        # log(sum(t_i/1s * exp(-Q/RT_i))); schedule summary, not a mechanistic proof.
        return float(logsumexp([np.log(h*3600.)-q/(8.314*(t+273.15)) for t,h in stages]))
    x['aging_kinetic_P']=d.apply(kinetic,axis=1)
    x['has_special_process']=d.special_process.fillna('').str.contains('pre-recovery|multi-stage|forging|pre-|RRA|two-step',case=False,regex=True).astype(float)
    return x[cols+DERIVED]
