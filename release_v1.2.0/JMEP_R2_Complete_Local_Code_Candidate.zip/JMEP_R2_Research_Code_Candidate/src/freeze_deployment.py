"""Freeze full-cohort nested choices and a historically motivated chemistry control.

No external property labels are accepted by the prediction interface. The fixed
chemistry control is a comparator added after historical development results;
it is not a new candidate in the previously frozen nested grid.
"""
from pathlib import Path
import argparse,json,sys,time,hashlib
import nested_publication_selection as n
import numpy as np
import pandas as pd
import joblib
from sklearn.compose import TransformedTargetRegressor
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold

HERE=Path(__file__).resolve().parent

def pipe(c):
 return TransformedTargetRegressor(regressor=make_pipeline(SimpleImputer(strategy='median',keep_empty_features=True),StandardScaler(),n.model(c)),transformer=StandardScaler())

def freeze(source,out):
 start=time.monotonic();d,x,columns=n.load(source);plan=json.loads((out/'frozen_plan.json').read_text(encoding='utf-8'))
 assert all(n.sha(source/f)==h for f,h in plan['source_sha256'].items())
 supplement=dict(status='FROZEN_BEFORE_EXTERNAL_PREDICTION',date_client='2026-11-05',parent_plan_sha256=n.sha(out/'frozen_plan.json'),source_sha256=plan['source_sha256'],
  deployment_selection='Same frozen21 candidates and innerGroupKFold3/equal-source MAE on all observed target labels in the98-row source cohort. Full-source choice is separate from outer-fold choices.',
  external_targets_used=False,external_matrices_used_for_selection=False,
  chemistry_control=dict(model='Ridge',alpha=10,representation='first18 nominal compositions',selection=False,
    history='Requested after existing project development studies identified a strong composition-only baseline, before current nested results were reported to root and before additional external predictions. Its implementation follows completion of the bounded nested run. It is not a newly preregistered hypothesis or an added nested-grid candidate.'),
  controls=['training_mean','ridge100_raw32','fixed_ET45','chem18_ridge10'],validation_reused_in_project=True)
 sp=out/'deployment_and_control_plan.json'
 if sp.exists():assert json.loads(sp.read_text(encoding='utf-8'))==supplement
 else:n.dump(sp,supplement)
 # Separate fixed composition-only outer control on exactly the same target/source partitions.
 control=[];controlmet=[]
 idx={r:i for i,r in enumerate(d.record_id)}
 chemical=x['raw32'][:,:18]
 chemc=dict(id='chem18__ridge10',representation='chem18',family='ridge',alpha=10)
 for f in plan['folds']:
  tr=np.array([idx[r] for r in f['training_ids']]);te=np.array([idx[r] for r in f['testing_ids']]);y=d[f['target']].to_numpy(float)
  pp,empty=n.fit_predict(chemc,chemical,y,tr,te)
  check=pipe(chemc);check.fit(chemical[tr],y[tr]);independent=check.predict(chemical[te]);assert np.max(np.abs(independent-pp))<1e-7
  for i,p in zip(te,pp):control.append(dict(model='chem18_ridge10',outer_group=f['outer_group'],target=f['target'],record_id=d.at[i,'record_id'],observed=float(y[i]),predicted=float(p),physical_invalid=bool(p<0 or(f['target']=='EL_pct' and p>100))))
 cp=pd.DataFrame(control);cp.to_csv(out/'chem18_control_outer_predictions.csv',index=False)
 for (t,g),q in cp.groupby(['target','outer_group']):controlmet.append(dict(model='chem18_ridge10',target=t,outer_group=g,**n.met(q.observed.to_numpy(),q.predicted.to_numpy())))
 cm=pd.DataFrame(controlmet);cm.to_csv(out/'chem18_control_metrics_per_source.csv',index=False)
 controlpooled=[]
 for t,q in cp.groupby('target'):
  z=cm[cm.target==t];controlpooled.append(dict(model='chem18_ridge10',target=t,**n.met(q.observed.to_numpy(),q.predicted.to_numpy()),macro_source_MAE=float(z.MAE.mean()),macro_source_RMSE=float(z.RMSE.mean()),evaluated_source_groups=len(z),invalid_predictions=int(q.physical_invalid.sum())))
 pd.DataFrame(controlpooled).to_csv(out/'chem18_control_metrics_pooled.csv',index=False)
 # Candidate choice uses only full-source inner out-of-fold observations.
 innerrows=[];score=[];folds=[];selected={};models={};candidate=plan['candidates']
 for target in n.TARGETS:
  y=d[target].to_numpy(float);obs=np.flatnonzero(np.isfinite(y));groups=d.iloc[obs].study_group.to_numpy()
  inner=[]
  for k,(aa,bb) in enumerate(GroupKFold(3).split(obs,groups=groups)):
   tr,va=obs[aa],obs[bb];assert set(d.iloc[tr].study_group).isdisjoint(d.iloc[va].study_group)
   inner.append((k,tr,va));folds.append(dict(target=target,inner_fold=k,training_ids=d.iloc[tr].record_id.tolist(),validation_ids=d.iloc[va].record_id.tolist()))
  local=[]
  for c in candidate:
   yp=[];yh=[];gg=[]
   for k,tr,va in inner:
    p,empty=n.fit_predict(c,x[c['representation']],y,tr,va);yp.extend(y[va]);yh.extend(p);gg.extend(d.iloc[va].study_group)
    for i,pred in zip(va,p):innerrows.append(dict(target=target,candidate_id=c['id'],inner_fold=k,source_group=d.at[i,'study_group'],record_id=d.at[i,'record_id'],observed=float(y[i]),predicted=float(pred)))
   q=pd.DataFrame({'y':yp,'p':yh,'g':gg});q['abs_error']=(q.y-q.p).abs()
   r=dict(target=target,candidate_id=c['id'],representation=c['representation'],family=c['family'],inner_macro_source_MAE=float(q.groupby('g').abs_error.mean().mean()),inner_pooled_MAE=float(q.abs_error.mean()),n=len(q))
   score.append(r);local.append(r)
  winner=min(local,key=lambda r:(r['inner_macro_source_MAE'],r['candidate_id']));selected[target]=winner
  chosen=next(c for c in candidate if c['id']==winner['candidate_id'])
  targetmodels={}
  for name,c,xx,cols in [('nested_joint',chosen,x[chosen['representation']],columns[chosen['representation']]),
    ('ridge100_raw32',dict(id='raw32__ridge_100',representation='raw32',family='ridge',alpha=100),x['raw32'],columns['raw32']),
    ('fixed_ET45',dict(id='aug45__ET_leaf1',representation='aug45',family='ET',n_estimators=500,max_features=.5,min_samples_leaf=1,random_state=42,n_jobs=1),x['aug45'],columns['aug45']),
    ('chem18_ridge10',chemc,chemical,columns['raw32'][:18])]:
   est=pipe(c);est.fit(xx[obs],y[obs]);targetmodels[name]=dict(estimator=est,columns=cols,candidate=c,n_train=len(obs),training_target_min=float(np.min(y[obs])),training_target_max=float(np.max(y[obs])))
  targetmodels['training_mean']=dict(constant=float(np.mean(y[obs])),columns=[],n_train=len(obs))
  models[target]=targetmodels
  print('DEPLOY_FROZEN',target,winner['candidate_id'],flush=True)
 pd.DataFrame(innerrows).to_csv(out/'full_source_inner_predictions.csv',index=False)
 pd.DataFrame(score).to_csv(out/'full_source_candidate_scores.csv',index=False)
 n.dump(out/'full_source_inner_folds.json',folds)
 n.dump(out/'deployment_selection.json',dict(status='FROZEN_NO_EXTERNAL_LABELS',selection=selected,source_sha256=plan['source_sha256'],candidate_grid_sha256=n.sha(out/'frozen_plan.json'),plan_sha256=n.sha(sp),historically_reused_cohort=True))
 joblib.dump(models,out/'deployment_models.joblib')
 n.dump(out/'deployment_lock.json',dict(models_sha256=n.sha(out/'deployment_models.joblib'),selection_sha256=n.sha(out/'deployment_selection.json'),plan_sha256=n.sha(sp),seconds=time.monotonic()-start,status='FROZEN_BEFORE_ADDITIONAL_EXTERNAL_PREDICTIONS'))
 print('DEPLOYMENT_DONE',round(time.monotonic()-start,1),'s',flush=True)

def predict(matrix45,matrix53,nested_dir=HERE):
 """Return predictions only. Dataframe/property columns are never used for choice.

 Both frames must have a unique record_id and named source-compatible inputs.
 32 raw/18 chemistry fields are derived from45. No model is fitted here.
 """
 lock=json.loads((nested_dir/'deployment_lock.json').read_text(encoding='utf-8'))
 assert n.sha(nested_dir/'deployment_models.joblib')==lock['models_sha256']
 assert n.sha(nested_dir/'deployment_selection.json')==lock['selection_sha256']
 a=matrix45.copy().set_index('record_id');b=matrix53.copy().set_index('record_id')
 assert a.index.is_unique and b.index.is_unique and a.index.equals(b.index)
 models=joblib.load(nested_dir/'deployment_models.joblib');out=[]
 for target,dd in models.items():
  for name,m in dd.items():
   if name=='training_mean':p=np.repeat(m['constant'],len(a));cid='training_mean';rep='none'
   else:
    cols=m['columns'];frame=b if m['candidate']['representation']=='state53' else a
    assert set(cols)<=set(frame.columns),set(cols)-set(frame.columns)
    p=m['estimator'].predict(frame[cols].to_numpy(float));cid=m['candidate']['id'];rep=m['candidate']['representation']
   for rid,pred in zip(a.index,p):out.append(dict(record_id=rid,target=target,model=name,candidate_id=cid,representation=rep,predicted=float(pred),physical_invalid=bool(pred<0 or(target=='EL_pct' and pred>100))))
 return pd.DataFrame(out)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,default=n.DEFAULT/'github_submission_fix');ap.add_argument('--out',type=Path,default=HERE);ap.add_argument('--freeze',action='store_true');ap.add_argument('--matrix45',type=Path);ap.add_argument('--matrix53',type=Path);ap.add_argument('--predictions',type=Path);a=ap.parse_args()
 if a.freeze:freeze(a.source.resolve(),a.out.resolve())
 if a.matrix45:
  assert a.matrix53 and a.predictions
  pred=predict(pd.read_csv(a.matrix45),pd.read_csv(a.matrix53),a.out.resolve());pred.to_csv(a.predictions,index=False);print('EXTERNAL_PREDICTIONS_WRITTEN',len(pred))
