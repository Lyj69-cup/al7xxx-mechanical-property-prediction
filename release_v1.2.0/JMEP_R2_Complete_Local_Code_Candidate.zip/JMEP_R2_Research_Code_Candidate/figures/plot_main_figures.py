"""Plot the pre-existing held-out and reference-budget forecasts; no model fit.

Input CSVs remain unchanged. The primary panel subset is the same seed42
publication-grouped ET comparison used in the earlier manuscript. The reference
figure includes all12queries and all4consumed reference conditions.
"""
from pathlib import Path
import argparse,json,hashlib,sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
if (ROOT/'analysis_work/pydeps').exists():sys.path.insert(0,str(ROOT/'analysis_work/pydeps'))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def metrics(y,p):
 e=p-y;return dict(n=len(y),R2=1-float(e@e)/float(np.sum((y-y.mean())**2)),MAE=float(np.abs(e).mean()))

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--primary',type=Path,default=ROOT/'analysis_work/github_submission_fix/results/traceable/predictions.csv')
 ap.add_argument('--reference',type=Path,default=ROOT/'analysis_work/r2_research_rebuild_20261105/reference_followup/scored_predictions.csv')
 ap.add_argument('--anchors',type=Path,default=ROOT/'analysis_work/r2_research_rebuild_20261105/reference_followup/consumed_anchors.csv')
 ap.add_argument('--out',type=Path,default=HERE/'figures')
 ap.add_argument('--audit-helpers',type=Path)
 args=ap.parse_args();out=args.out;out.mkdir(parents=True,exist_ok=True)
 if args.audit_helpers:
  sys.path.insert(0,str(args.audit_helpers))
  from audit_panel_alignment import require_matplotlib_panel_alignment
 else:
  require_matplotlib_panel_alignment=None
 plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans','Arial'],'font.size':8,'axes.labelsize':8,'xtick.labelsize':7.5,'ytick.labelsize':7.5,'axes.titlesize':8.5,'legend.fontsize':7.5,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
 report={'status':'PASS','no_refitting_or_selection':True,'source_hashes':{p.name:sha(p)for p in [args.primary,args.reference,args.anchors]},'figures':{}}
 def save(fig,name,axes):
  fig.canvas.draw()
  if require_matplotlib_panel_alignment:
   require_matplotlib_panel_alignment(fig,json_out=out/(name+'.alignment.json'),tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True)
  # Portable explicit equal-grid geometry check independent of the skill helper.
  boxes=np.array([[a.get_position().x0*fig.get_figwidth()*72,a.get_position().y0*fig.get_figheight()*72,a.get_position().width*fig.get_figwidth()*72,a.get_position().height*fig.get_figheight()*72]for a in axes])
  assert np.ptp(boxes[:,2])<=1.5 and np.ptp(boxes[:,3])<=1.5,boxes
  (out/(name+'.portable_alignment.json')).write_text(json.dumps({'plot_rectangles_pt':boxes.tolist(),'equal_width_height_tolerance_pt':1.5,'status':'PASS'},indent=2),encoding='utf-8')
  fig.savefig(out/(name+'.pdf'))
  fig.savefig(out/(name+'.svg'))
  fig.savefig(out/(name+'.png'),dpi=300)
  fig.savefig(out/(name+'.tif'),dpi=1200,pil_kwargs={'compression':'tiff_lzw'})
  plt.close(fig)

 p=pd.read_csv(args.primary)
 q=p[(p.cohort=='primary')&(p.kind=='augmented')&(p.protocol=='study_grouped')&(p.seed==42)&(p.model=='ET')].copy()
 assert len(q)==44+98+86 and not q.duplicated(['target','record_id']).any()
 q.to_csv(out/'Fig1_source_data.csv',index=False)
 fig,axs=plt.subplots(1,3,figsize=(7.05,2.6))
 fig.subplots_adjust(left=.075,right=.985,bottom=.23,top=.86,wspace=.42)
 met=[]
 for ax,t,label,unit,letter in zip(axs,['YS_MPa','UTS_MPa','EL_pct'],['YS','UTS','EL'],['MPa','MPa','%'],'abc'):
  g=q[q.target==t];y=g.observed.to_numpy();pred=g.predicted.to_numpy();m=metrics(y,pred);met.append({'target':t,**m})
  lo=min(y.min(),pred.min());hi=max(y.max(),pred.max());pad=.07*(hi-lo)
  ax.plot([lo-pad,hi+pad],[lo-pad,hi+pad],color='#666666',ls='--',lw=.8,zorder=1)
  ax.scatter(y,pred,s=13,color='#0072B2',alpha=.65,edgecolors='none',zorder=2)
  ax.set(xlim=(lo-pad,hi+pad),ylim=(lo-pad,hi+pad),xlabel=f'Reported {label} ({unit})',ylabel=f'Predicted {label} ({unit})',title=f'{label}   n = {len(g)}')
  ax.text(0,1.10,letter,transform=ax.transAxes,fontweight='bold',fontsize=10)
  ax.grid(alpha=.13,linewidth=.5)
 save(fig,'Fig1_primary_publication',list(axs))
 report['figures']['Fig1']={'observations':len(q),'source_population':98,'filter':'primary/augmented/study_grouped/seed42/ET','metrics':met,'statistical_unit':'Published condition summary; target-specific masks; no specimen-level uncertainty inferred'}

 r=pd.read_csv(args.reference);anchors=pd.read_csv(args.anchors)
 assert r.record_id.nunique()==12 and len(anchors)==4 and r.method.nunique()==12
 r.to_csv(out/'Fig2_all_methods_source_data.csv',index=False)
 anchors.to_csv(out/'Fig2_reference_conditions.csv',index=False)
 methods=[('zero_shot__nested_joint','Zero reference','#999999','s','--'),('anchor_constant','Reference constant','#666666','x',':'),('anchor_offset__fixed_ET45','ET + reference','#D55E00','s','-.'),('anchor_offset__nested_joint','Nested + reference','#0072B2','^','-')]
 series=[('HV32-S05','Li et al., 120 °C'),('HV32-S08','Sajadifar et al., 105 °C'),('HV32-S09','Sajadifar et al., 120 °C'),('HV32-S12','Zhao et al., 140 °C')]
 fig,axs=plt.subplots(2,2,figsize=(7.05,5.1))
 fig.subplots_adjust(left=.095,right=.985,bottom=.10,top=.80,wspace=.23,hspace=.55)
 legend=[]
 for ax,(sid,title),letter in zip(axs.flat,series,'abcd'):
  sub=r[r.series_id==sid];obs=sub.drop_duplicates('record_id').sort_values('aging_time_h');a=anchors[anchors.series_id==sid].iloc[0]
  assert len(obs)==(4 if sid in ['HV32-S05','HV32-S12']else 2)
  x=obs.aging_time_h.to_numpy(float)
  measured=ax.errorbar(x,obs.observed,yerr=obs.reading_half_range_MPa,color='black',fmt='o',markersize=4.0,elinewidth=.7,capsize=2,label='Reported query UTS',zorder=5)
  reference=ax.scatter([a.aging_time_h],[a.observed],facecolors='white',edgecolors='black',marker='D',s=24,label='Consumed reference',zorder=5)
  handles=[measured,reference]
  for method,label,color,marker,ls in methods:
   g=sub[sub.method==method].sort_values('aging_time_h')
   h,=ax.plot(g.aging_time_h,g.predicted,color=color,marker=marker,ls=ls,markersize=3.3,lw=1.05,label=label,zorder=3);handles.append(h)
  ax.set(title=title,xlabel='Artificial aging time (h)',ylabel='UTS (MPa)')
  ax.set_xticks([a.aging_time_h,*x])
  ax.text(0,1.16,letter,transform=ax.transAxes,fontweight='bold',fontsize=10)
  ax.grid(alpha=.13,linewidth=.5)
  if not legend:legend=handles
 fig.legend(legend,['Reported query UTS','Consumed reference',*[m[1]for m in methods]],loc='upper center',bbox_to_anchor=(.53,.985),ncol=3,frameon=False,columnspacing=1.4,handlelength=2.2)
 save(fig,'Fig2_reference_followup',list(axs.flat))
 report['figures']['Fig2']={'query_conditions':12,'consumed_reference_conditions':4,'publications':3,'series':4,'displayed_prediction_methods':[m[0]for m in methods],'all12methods_retained_in_source_csv':True,'whiskers':'Analyst reading allowance±3MPa or printed rounding allowance±0.05MPa; not SD or confidence interval','line_segments':'Guides between evaluated conditions; not fitted kinetic curves','references_scored':False}
 (out/'figure_integrity.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
