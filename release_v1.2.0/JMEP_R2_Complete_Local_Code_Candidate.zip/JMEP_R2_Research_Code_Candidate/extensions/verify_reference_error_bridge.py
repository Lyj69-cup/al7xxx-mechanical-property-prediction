"""Verify an error identity from archived predictions; no fitting or selection.

This is an explanatory diagnostic evaluated after observing the query outcomes.
It is neither a new algorithm nor a way to know future error from one reference.
"""
from pathlib import Path
import csv,json,hashlib,math
from decimal import Decimal,localcontext

ROOT=Path(__file__).resolve().parents[1]
T=ROOT/'recomputed/reference_bridge'
T.mkdir(parents=True,exist_ok=True)
R=ROOT/'archive_results'
MODELS=['nested_joint','fixed_ET45','ridge100_raw32','chem18_ridge10','training_mean']

def rows(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def D(v):return Decimal(str(v))
def mean(a):return sum(a,D(0))/len(a)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,records):
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)

input_files=[R/'one_reference/scored_predictions.csv',R/'one_reference/consumed_anchor_measurements.csv',
 R/'external/scored_predictions.csv',R/'reference_followup/scored_predictions.csv',
 R/'reference_followup/consumed_anchors.csv',R/'reference_followup/zero_shot_all_conditions.csv']
original_hashes={str(p.relative_to(R)):sha(p) for p in input_files}
development,devanchors,external,followup,followanchors,followzero=map(rows,input_files)
external_index={(r['record_id'],r['target'],r['model']):r for r in external}
followzero_index={(r['record_id'],r['target'],r['model']):r for r in followzero}
summary=[];details=[];max_identity=D(0);max_std=D(0);max_mean_identity=D(0)

with localcontext() as ctx:
    ctx.prec=45
    for phase,scored,anchors in [('development',development,devanchors),('followup',followup,followanchors)]:
        for ar in anchors:
            aid=ar['record_id'];sid=ar['source_id'];target=ar['target']
            series=ar.get('series_id',sid)
            ya=D(ar.get('observed_anchor',ar.get('observed')))
            pool=[r for r in scored if r['source_id']==sid and r['target']==target and r['anchor_record']==aid]
            constants={r['record_id']:r for r in pool if r['method']=='anchor_constant'}
            assert aid not in constants and constants
            for model in MODELS:
                index=external_index if phase=='development' else followzero_index
                pa=D(index[(aid,target,model)]['predicted']);ea=pa-ya
                zero={r['record_id']:r for r in pool if r['method']=='zero_shot__'+model}
                offset={r['record_id']:r for r in pool if r['method']=='anchor_offset__'+model}
                assert set(zero)==set(offset)==set(constants)
                ez=[];ec=[];ecst=[]
                for rid in sorted(zero):
                    z,c,k=zero[rid],offset[rid],constants[rid]
                    y=D(z['observed']);assert y==D(c['observed'])==D(k['observed'])
                    e0=D(z['predicted'])-y;er=D(c['predicted'])-y
                    delta=abs(er-(e0-ea));max_identity=max(max_identity,delta)
                    assert delta<D('1e-9')
                    # The point charged as the reference is not in query scoring.
                    assert rid!=aid
                    assert abs(D(k['predicted'])-ya)<D('1e-9')
                    details.append(dict(phase=phase,source_id=sid,series_id=series,target=target,model=model,
                     record_id=rid,anchor_record=aid,anchor_error=ea,query_zero_error=e0,
                     expected_offset_error=e0-ea,archived_offset_error=er,identity_abs_difference=delta))
                    ez.append(e0);ec.append(er);ecst.append(D(k['predicted'])-y)
                mz,mc=mean(ez),mean(ec)
                stdz=mean([(e-mz)**2 for e in ez]).sqrt();stdc=mean([(e-mc)**2 for e in ec]).sqrt()
                mean_delta=abs(mc-(mz-ea));max_mean_identity=max(max_mean_identity,mean_delta)
                std_delta=abs(stdz-stdc);max_std=max(max_std,std_delta)
                assert mean_delta<D('1e-9') and std_delta<D('1e-9')
                summary.append(dict(phase=phase,source_id=sid,series_id=series,target=target,model=model,n_queries=len(ez),
                  anchor_record=aid,anchor_observed=ya,anchor_predicted=pa,anchor_error=ea,
                  zero_query_bias=mz,offset_query_bias=mc,zero_query_MAE=mean([abs(e) for e in ez]),
                  offset_query_MAE=mean([abs(e) for e in ec]),constant_query_MAE=mean([abs(e) for e in ecst]),
                  zero_query_RMSE=mean([e*e for e in ez]).sqrt(),offset_query_RMSE=mean([e*e for e in ec]).sqrt(),
                  zero_query_centered_error_SD=stdz,offset_query_centered_error_SD=stdc,
                  zero_error_min=min(ez),zero_error_max=max(ez),
                  query_record_ids=json.dumps(sorted(zero))))

assert len(summary)==45 and len(details)==150,(len(summary),len(details))
assert original_hashes=={str(p.relative_to(R)):sha(p) for p in input_files}
write(T/'reference_error_bridge.csv',summary)
write(T/'reference_error_bridge_per_query.csv',details)
report=dict(status='PASS',source_input_sha256=original_hashes,summary_rows=len(summary),query_model_identities=len(details),
 max_identity_abs_difference=str(max_identity),max_mean_bias_identity_difference=str(max_mean_identity),
 max_centered_error_SD_difference=str(max_std),models_fitted=0,models_selected=0,
 reference_conditions_scored_as_queries=False,source_files_unchanged=True,
 statistical_intervals_or_tests_added=False,
 interpretation='Additive calibration subtracts the fixed reference residual from every query residual. It shifts error level while leaving the within-series centered error spread unchanged. This post-outcome identity does not reveal future query error or repair unspecified processing-state response.',
 source_scope='Two development sources/five available targets and all four UTS follow-up series; all five frozen source-trained methods retained.')
(T/'reference_error_bridge_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
for r in summary:
    if r['model']=='nested_joint' and (r['phase']=='followup' or (r['source_id'],r['target']) in [('HE2025','UTS_MPa'),('JIANG_AMS2026','UTS_MPa'),('HE2025','YS_MPa')]):
        print(r['phase'],r['source_id'],r['series_id'],r['target'],'anchor',float(r['anchor_error']),'querybias',float(r['zero_query_bias']),'MAE',float(r['zero_query_MAE']),'->',float(r['offset_query_MAE']),'constant',float(r['constant_query_MAE']))
