# Numerical reproduction of the additional revision analyses

This local snapshot reproduces the source-resolved validation, recorded-state
distinctions and reference-information comparisons in the revised paper. It
contains the frozen analyses, source-qualified records, complete query controls,
and reproducible main-figure data. Publication and persistent archiving await
author review of the complete revision.

## Run

Use Python 3.12 or 3.13 and an isolated environment. The pinned versions are those
used for the recorded computations. In a terminal in this folder:

```text
python -m pip install -r requirements.txt
python run_reproduction.py
```

The default run first verifies the immutable input manifest, reconstructs all
45/53-field matrices from the curated condition ledgers, refits the twelve frozen
full-cohort target/model pipelines, and compares the resulting 285 external and
80 follow-up zero-shot forecasts with the archived values. It then recomputes
three original-source-only log-time slopes, all 216 development reference
forecasts and 144 follow-up forecasts, all corresponding metrics and bounded
readout sensitivities, and all 256 state-field subsets. A PASS requires maximum
prediction and metric deviations below 1e-7 and the original unique seven-field
minimum. Outputs are written only to `recomputed/`.

The default run uses already recorded full-cohort deployment choices; it does
not present their in-sample performance as unbiased validation. To repeat the
entire frozen 21-candidate grid, all source-held-out selection and full-cohort
deployment selection as well:

```text
python run_reproduction.py --nested
```

The optional step repeats 1,487 source-held-out fits plus the separately recorded
deployment/control fits. It writes to fresh `recomputed/nested_model/`, compares
outer predictions and selections, and checks that full-cohort choices remain
YS raw32 ET leaf3, UTS augmented45 Ridge alpha1000 and EL augmented45 Ridge
alpha100. It does not change the candidate grid or original archived results.
The small fixed chemistry-only Ridge is a historical comparator, not an added
nested-grid candidate. No serialized model needs to be trusted or loaded by the
default run. The optional original deployment script writes its own fresh
joblib artifact under `recomputed/`; it is not loaded or distributed in this ZIP.

## Inputs and evidence

- `input_base/data/`: the same 98 primary condition summaries, 44/98/86 YS/UTS/EL
  labels, eight linked publication groups, and un-imputed 45/53-column matrices.
- `input_external/`: 19 conditions and 53 available targets. He five and Zhang
  eight table conditions are primary; Zhang two T6 prose triplets and Jiang four
  UTS/EL means are separately qualified supplementary cases. Jiang has no
  numerical measured YS; those predictions are not scored.
- `input_followup/`: sixteen conditions, four consumed UTS reference values and
  twelve queries from three publications/four series. Sajadifar's two series
  belong to one publication, not two independent studies.
- `archive_results/`: unchanged plans, scores, choices, unrounded predictions,
  provenance qualifications and checks produced by the preceding research run.
- `src/`: original nested/deployment scripts and a dependency-light extraction
  of the unchanged original feature transform.
- `source_attribution/` and `ATTRIBUTION.md`: DOI metadata, reporting limits,
  literature comparison and license scope. The four-condition Jiang phase table
  accompanies the tensile context; its particle-number fractions are not volume
  fractions, fitted causal coefficients or additional regression replicates.

These numerical reproductions begin at curated source ledgers. They do not
automate original-paper transcription or certify original experiment identities.
All unreported fields remain missing. A coupon thickness is not automatically a
product gauge, manufacturing reduction is not pre-aging deformation, and an
unreported testing temperature is not silently treated as room temperature.
No full texts or extracted full-text pages are redistributed.

## Information budgets and limits

Zero-reference predictions use the original 98 training summaries only. A
reference-corrected prediction consumes a condition-level reported tensile
statistic and uses `y_anchor + f(x_query) - f(x_anchor)`. This may represent several
tensile specimens and is not a free measurement or proof that one specimen
suffices. Reference-constant and log-time controls use the same reference budget.
All twelve methods use identical query sets. No clipping, query-target fitting,
per-source winner replacement or outcome-based series deletion is performed.

The reference hypothesis was introduced after seeing the He success and Jiang
failure. Follow-up targets had already been inspected in a related project.
Plans frozen before the current predictions do not make these cases untouched
or preregistered. Follow-up nominal UTS MAE is 7.652 MPa for the frozen nested
offset versus 9.700 for a constant reference and 23.871 for zero-reference
prediction. Fixed ET-offset is better at 6.281, and the simple log-time control
beats nested offset on Zhao. No unique machine-learning superiority is shown.

The ±3 MPa graph-reading allowances and ±0.05 MPa printed-rounding allowance are
conditional sensitivity assumptions, not experimental SDs, confidence intervals
or guaranteed physical uncertainty. The seven-field minimum distinguishes the
fifteen existing collision pairs; it is not a universal descriptor requirement
or proof of predictive sufficiency on new studies.

Floating-point results are checked by tolerance, not promised bitwise identical
across compiled platforms. The new bounded grid does not include XGBoost or
LightGBM; original-release platform-sensitive results remain in that release.

## Main figures and the reference-error diagnostic

The two main figures are computed directly from archived predictions. The
first retains all 44/98/86 available primary labels from the previously used
publication-grouped seed42 ET comparison. The second retains all12query
conditions and identifies four consumed references separately. Its source CSV
retains all12methods; the main graph displays the declared selected predictor,
ET control and reference-constant comparison. Whiskers are reading/rounding
allowances, not experimental SDs or confidence intervals.

```text
python figures/plot_main_figures.py --primary figures/source_data/Fig1_source_data.csv --reference figures/source_data/Fig2_all_methods_source_data.csv --anchors figures/source_data/Fig2_reference_conditions.csv --out recomputed/figures
python extensions/verify_reference_error_bridge.py
```

The independent bridge implementation reads the archived forecasts and verifies
all150query/model identities and45source/target/model summaries using Decimal
arithmetic. Its outputs are written under recomputed/reference_bridge/. The
identity explains reference-level shifts in observed residuals; prospective
query error remains unknown. No new regressor is fitted by either extension.

VectorPDF/SVG and1200dpiTIFF main artwork, plot-area alignment and collision
checks accompany the plotting source. Floating-point and rendering tolerances,
rather than bitwise cross-platform equality, apply. The manuscript reference
crosswalk maps historical source labels to the narrative revision numbering.
