# 单参考校准与少样本迁移：有界补充核查

核查日期：2026-11-05。范围限定为4条定向检索，后续仅打开已发现的一手页面和DOI元数据；没有修改原有10篇对照矩阵、训练或发表文件。原始元数据及抓取记录见 `calibration_source_metadata.json`；逐来源资格、锚点和当前结果快照见 `calibration_evidence_sources.json`。

**结论：不能把单参考加性修正称为新算法，也不能声称首次在7xxx中使用少样本迁移。** 本次找到了明确的同体系迁移学习先例和包含7075的少量实验校准先例。4条检索没有核实到一篇7xxx原始论文使用完全相同的单参考公式；这个未检出结果不构成“首次使用”的证据。

## 公式究竟做了什么

所用预测为

\[
\widehat y_q=y_a+f(x_q)-f(x_a)=f(x_q)+\widehat b,\qquad \widehat b=y_a-f(x_a).
\]

在固定模型 `f` 后，这正是用一个参考残差估计一个加性截距。对单个参考点最小化平方损失或绝对损失都会得到上述截距；不需要新的网络、训练损失或优化算法。若记未修正预测误差为 `e(x)=f(x)-y(x)`，修正后的查询误差就是 `e(x_q)−e(x_a)`。它是否有用取决于两处模型偏差是否相近，并且会传播参考值的测量不确定性。参考条件处误差为零是构造结果，所以该点必须从查询评价中排除。

可称其为 **one-reference additive calibration** 或 **reference-based offset correction**。若使用“transfer”，应说明它是固定模型的目标系列截距校正，而不是新提出的迁移学习架构。

## 最接近的一手文献

### 1. 同一合金族的目标数据辅助迁移：Jiang et al., 2023

**L. Jiang, Z. Zhang, H. Hu, X. He, H. Fu, and J. Xie**, *A rapid and effective method for alloy materials design via sample data transfer machine learning*, **npj Computational Materials 9, Article26 (2023)**，2023-02-22上线。[出版社原文](https://www.nature.com/articles/s41524-023-00979-9)，[DOI](https://doi.org/10.1038/s41524-023-00979-9)。官方全文已读，Crossref独立核对了题名、全部作者、日期及文章号。

- 任务：AA7xxx成分/多阶段固溶时效参数→UTS和伸长率，用已有商业合金信息优化E2新合金热处理。
- 数据：1,053条商业AA7xxx数据，另有20个E2预实验条件。Methods将20个目标条件随机按4:1分为TDS4/TDS1，即16个目标训练、4个目标测试条件。
- 方法：TrAdaBoost根据源域/目标域误差改变样本权重；TDS4内五折调整树数与深度，然后用NSGA-II设计工艺。
- 结果：原文给目标测试MAPE约UTS3.4%、EL8.4%；实际制备7组优化处理，最佳UTS767±6MPa、EL13.4±0.5%。不同数据预算和任务下，不能直接与本稿MPa MAE排名。
- 锚点：Results的Strategy/Fig.2；Methods的Construction of datasets及TrAdaBoost algorithm；Table1实际试验。
- 关系：这是**直接同体系的小目标数据迁移和过程优化先例**。它没有在已查方法中使用本稿的单参考公式，因此不能把两者说成完全相同。方法段还描述按测试MAPE选择最终模型，不能将其重新包装成无测试集选择的嵌套研究留出方案。

### 2. 7075少量实验数据校准先例：Lu et al., 2020

**L. Lu, M. Dao, P. Kumar, U. Ramamurty, G.E. Karniadakis, and S. Suresh**, *Extraction of mechanical properties of materials through deep learning from instrumented indentation*, **PNAS117(13),7052–7062 (2020)**，2020-03-16上线。[官方原文](https://www.pnas.org/doi/10.1073/pnas.1922210117)。

原文的 **Transfer Learning节和Fig.10**：先用2D/3D有限元数据训练多保真网络，再只更新高保真子网络；铝合金Al6061-T6511和Al7075-T651使用3个实验数据点进行适配。其测量输入是压痕响应，输出是弹塑性参数，与成分/工艺→UTS的任务不同，也不是一个参考拉伸均值的加性修正。它仍明确表明“已有模型加少量目标实验数据纠正系统误差”在含7075的力学性能研究中已有实验先例。

### 3. 同体系主效应加修正：Bai et al., 2026

[官方论文](https://www.sciencedirect.com/science/article/pii/S0925838826036728)，[DOI10.1016/j.jallcom.2026.189603](https://doi.org/10.1016/j.jallcom.2026.189603)，**J. Alloys Compd.1077,189603**，卷期2026-07-15。已核实的官方摘要/片段采用RF主成分与热处理效应加XGBoost微合金增量，并以Sc试验验证。它是相关的基线加修正先例；不是本稿逐系列单参考偏置校准的证据。详细训练规模和划分未从全文核实。

### 4. 不用于过度主张的两个发现

- **Ramakrishnan et al., 2015**, *Big Data Meets Quantum Chemistry Approximations: The Δ-Machine Learning Approach*, J. Chem. Theory Comput.11:2087–2096，[DOI10.1021/acs.jctc.5b00099](https://doi.org/10.1021/acs.jctc.5b00099)。题录已核实，ACS原文此次403，没有重读原始公式。因此本补充不将其当作完全同式的铝合金校准证据；若正文要详细解释Δ-ML，仍需原文方法核对。
- **Sun et al.**, *Transfer learning-enabled high-precision prediction and multi-objective design of cryogenic aluminum alloys with enhanced strength-ductility synergy*，[官方摘要](https://www.sciencedirect.com/science/article/pii/S3050914926002359)，DOI10.1016/j.tramat.2026.100394。Crossref和页面给2026年12月卷期，无published-online字段；VoR许可始于2026-07-24，但许可日期/元数据创建日期不能单独证明最早公开发表日期。因此不把它作为截至11月5日的优先权结论依据。2020/2023已确认先例足以支持收窄主张。

## 本项目结果能支持到哪里

已读取主分析 `reference_followup/metrics_summary.csv`、`metrics_by_source.csv`、`followup_frozen_plan.json` 和独立复算审计结果。**这是受初次He校准结果启发的回溯后续分析；3篇论文在相关硬度项目中已被查看。** 虽然本轮UTS预测前锁定了当前方案，但不能称为完全未接触的前瞻确认。

共同评价单位为3篇论文、4个固定温度时效系列的12个非参考UTS条件；每系列消耗1个最早合格参考值，共4个参考。各方法使用相同查询集合。

| 方法 | 合并UTS MAE（MPa） | 解释 |
|---|---:|---|
| 直接使用参考值 | 9.700 | 必须提供的同参考信息预算基线 |
| 固定训练模型nested_joint，零目标参考 | 23.871 | 使用较少目标信息，与校准方法的信息成本不同 |
| nested_joint加单参考修正 | 7.652 | 在这12个回溯查询中，较参考常数改善2.048MPa，约21.1% |
| 固定ET45加相同参考修正 | 6.281 | 在此后续集合优于nested_joint，故不能宣称nested选择唯一优越 |
| 原始输入岭回归加参考修正 | 6.736 | 简单回归也有竞争力 |

在Zhao2020的4个查询上，源数据训练的简单log-time斜率加参考 MAE4.963MPa，优于nested修正6.492MPa。跨3个研究汇总，该简单斜率的MAE10.966MPa；因此也不能由单篇胜负宣布普遍优势。

这支持一个**有限但具体的工程发现**：当新系列提供一个参考值时，一些源训练模型可更好追踪后续条件变化；收益依赖于模型和系列。它不证明该校准发明了一种新算法、所有系列均改善、参考测量免费、统计显著或能够直接设计更优合金。只有3个研究，不应把12个查询当作12个独立研究；报告的读数容许区间也不是置信区间。

## 可用的英文贡献段落

下段158词，单独存为 `contribution_paragraph_en.txt`。它报告回溯事实，未使用first/novel architecture/unique superiority等未经证明的表述。

> We provide a retrospective, source-resolved assessment of what mechanical-property models can support in Al–Zn–Mg–Cu alloys. The study separates loss of experimental-state information from transfer error and evaluates standard predictive and reference-corrected baselines on matched conditions. In a retrospective follow-up covering 12 non-anchor UTS conditions from four aging series in three previously examined publications, one measured reference per series reduced the nested model’s pooled MAE from 23.87 to 7.65 MPa, compared with 9.70 MPa for simply retaining the reference value. Performance remained method-dependent: fixed ExtraTrees with the same correction achieved 6.28 MPa, while a simple source-trained log-time slope outperformed the nested correction in one study. These results identify a limited practical role for reference measurements alongside the need for complete processing histories. The contribution is the provenance-qualified comparison and its conditional engineering evidence, using established regression and calibration ideas. The follow-up is retrospective, consumes four reference measurements, and provides neither prospective validation nor evidence of a uniquely superior algorithm.

## 检索与不确定性记录

仅4条检索：

1. `"Al-Zn-Mg-Cu" "transfer learning"`
2. `"Al-Zn-Mg-Cu" "few-shot" OR "calibration"`
3. `"aluminum alloys" "mechanical properties" "transfer learning"`
4. `"delta-machine learning" "baseline" "target" Ramakrishnan 2015`

仅将原始研究出版社页面/Crossref作为核实依据，未用检索中出现的综述、ResearchGate或聚合网站支持方法结论。Nature的web工具遇身份重定向500，官方HTML经系统信任TLS成功读取；PNAS官方全文可读；ACS和ScienceDirect部分直接访问403。没有绕过登录或访问限制。该有界检索不能证明不存在其他更近的校准论文，足以支持“采用已有校准/迁移思想，贡献在回溯验证与条件证据”的稳健定位。
